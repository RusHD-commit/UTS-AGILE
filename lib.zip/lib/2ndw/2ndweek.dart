import 'package:flutter/material.dart';

class M02 extends StatefulWidget {
  const M02({super.key});

  @override
  State<M02> createState() => _M02State();
}

class _M02State extends State<M02> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
