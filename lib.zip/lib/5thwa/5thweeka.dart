import 'package:flutter/material.dart';

class M05A extends StatefulWidget {
  const M05A({super.key});

  @override
  State<M05A> createState() => _M05AState();
}

class _M05AState extends State<M05A> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
