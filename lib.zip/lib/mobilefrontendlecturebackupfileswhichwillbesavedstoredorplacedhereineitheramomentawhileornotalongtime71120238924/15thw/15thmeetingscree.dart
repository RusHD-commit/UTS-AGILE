import 'package:flutter/material.dart';

class M15 extends StatefulWidget {
  const M15({Key? key}) : super(key: key);

  @override
  State<M15> createState() => _M15State();
}

class _M15State extends State<M15> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('M15'),
      ),
      //body: const Text('M15'),
    );
  }
}
