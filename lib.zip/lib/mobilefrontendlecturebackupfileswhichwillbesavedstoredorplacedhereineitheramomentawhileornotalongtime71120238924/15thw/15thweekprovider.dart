import 'package:flutter/material.dart';

class M15Provider extends ChangeNotifier {
  bool _isImageloaded = false;
  bool get isImageLoaded => _isImageloaded;
  set setIsImageLoaded(val) {
    _isImageloaded = val;
    notifyListeners();
  }

  final ImagePicker _imagePicker = ImagePicker();

  XFile? _img;
  
}
