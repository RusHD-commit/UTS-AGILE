import 'package:flutter/material.dart';

class M01 extends StatefulWidget {
  String title;
  M01({super.key, required this.title});

  @override
  State<M01> createState() => _M01State();
}

class _M01State extends State<M01> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${widget.title}",
          style: TextStyle(
            fontSize: 30,
          ),
        ),
      ),
      body: Column(
        children: [
          //text
          Text(
            'Text1',
            style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 30,
                fontFamily: "arial",
                color: Colors.pinkAccent,
                letterSpacing: 2),
          ),
          //icon

          const Icon(
            Icons.check_circle_outline_rounded,
            color: Color.fromARGB(255, 65, 45, 100),
            size: 50,
          ),

          //image or pic
          Image.asset('assets/emmaw.png', width: 200),
        ],
      ),
    );
  }
}
