import 'package:flutter/material.dart';

class M02 extends StatefulWidget {
  const M02({super.key});

  @override
  State<M02> createState() => _M02State();
}

class _M02State extends State<M02> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Rusdi Hardjo",
          style: TextStyle(
            fontSize: 30,
          ),
        ),
      ),
      body: Column(
        children: [
          //align
          Center(
            child: Container(
              height: 100.0,
              width: 100.0,
              color: Colors.yellow,
              child: Align(
                alignment: const FractionalOffset(0.2, 0.6),
                child: Container(
                  height: 40.0,
                  width: 40.0,
                  color: Colors.red,
                ),
              ),
            ),
          ),
          //row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('assets/ava1.png', width: 100),
              Image.asset('assets/ava2.png', width: 100),
              Image.asset('assets/ava3.png', width: 100),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset('assets/ava1.png', width: 50),
                  Image.asset('assets/ava2.png', width: 50),
                  Image.asset('assets/ava3.png', width: 50),
                ],
              )
            ],
          )
        ],
      ),
    );
  }
}
