import 'package:flutter/material.dart';
import '2ndmeetingScreen.dart';

class M02A extends StatefulWidget {
  const M02A({super.key});

  @override
  State<M02A> createState() => _M02AState();
}

class _M02AState extends State<M02A> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: Center(
        child: ElevatedButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const M02()));
            },
            child: const Text('Profile Detail')),
      ),
    );
  }
}
