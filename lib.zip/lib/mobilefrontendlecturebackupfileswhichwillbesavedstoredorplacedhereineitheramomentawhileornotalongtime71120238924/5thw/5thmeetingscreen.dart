import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/5thw/5thmeeting_provider.dart';

class M05M extends StatefulWidget {
  const M05M({super.key});

  @override
  State<M05M> createState() => _M05MState();
}

class _M05MState extends State<M05M> {
  bool? q1a = false;
  bool? q1b = false;

  String q2 = 'answ';

  bool Morningclass = false;
  bool Afternoonclass = false;

  @override
  Widget build(BuildContext context) {
    //final prov = Provider.of<M05MProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('title'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //1st Question Using Checkbox
              const Text('1. '),
              Row(
                children: [
                  Text('a. '),
                  SizedBox(
                    width: 5,
                  ),
                  Checkbox(
                    value: q1a,
                    onChanged: (val) {
                      setState(() {
                        q1a = val;
                      });
                    },
                  ),
                  Text('RAM'),
                ],
              ),
              Row(
                children: [
                  Text('b. '),
                  SizedBox(
                    width: 5,
                  ),
                  Checkbox(
                    value: q1b,
                    onChanged: (val) {
                      setState(() {
                        q1b = val;
                      });
                    },
                  ),
                  Text('Random Access Memory'),
                ],
              ),
              //1st question response
              if (q1a == false && q1b == false)
                Container()
              else if (q1a == true && q1b == true)
                const Text('True')
              else
                const Text(
                  'False',
                  style: TextStyle(
                    color: Colors.pinkAccent,
                  ),
                ),

              const Divider(),

              //2nd question; The usage of Checkbox
              const Text('2. '),
              Row(
                children: [
                  Text('a. '),
                  SizedBox(width: 5),
                  Radio(
                    value: 'topology',
                    groupValue: q2,
                    onChanged: (val) {
                      setState(() {
                        q2 = 'topology';
                      });
                    },
                  ),
                  Text('Topology')
                ],
              ),
              Row(
                children: [
                  Text('b. '),
                  SizedBox(width: 5),
                  Radio(
                    value: 'design network',
                    groupValue: q2,
                    onChanged: (val) {
                      setState(() {
                        q2 = 'design network';
                      });
                    },
                  ),
                  Text('Design Network')
                ],
              ),

              //Answercheck

              if (q2 == 'answ')
                Container()
              else if (q2 == 'topology')
                const Text('True')
              else
                const Text(
                  'False',
                  style: TextStyle(
                    color: Colors.pinkAccent,
                  ),
                ),

              //Chips
              //ChoiceorOptionChip
              const Divider(),
              const Text(
                'Question Feedback',
              ),
              const Text('Class'),
              Row(
                children: [
                  ChoiceChip(
                    label: Text('Morning'),
                    selectedColor: Color.fromARGB(255, 88, 105, 134),
                    selected: Morningclass,
                    onSelected: (val) {
                      setState(() {
                        Morningclass = val;
                      });
                    },
                  ),
                  ChoiceChip(
                    label: Text('Afternoon'),
                    selectedColor: Color.fromARGB(255, 88, 105, 134),
                    selected: Afternoonclass,
                    onSelected: (val) {
                      setState(() {
                        Afternoonclass = val;
                      });
                    },
                  ),
                ],
              ),
              const Text(''),
              Row(
                children: [],
              ),

              //InputChip
              const Text('Your High School Elective'),
              Container(),
              Row()
            ],
          ),
        ),
      ),
    );
  }
}
