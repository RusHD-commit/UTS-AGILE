import 'package:flutter/material.dart';

class M05MProvider extends ChangeNotifier {
  //status

  //First Value Initialization
  bool _inSch = false;
  bool _inPra = true;
  bool _inCou = false;

  //

  bool get schstatus => _inSch;
  bool get prastatus => _inPra;
  bool get coustatus => _inCou;

  //

  set setSch(val) {
    _inSch = val;
    notifyListeners();
  }

  set setPra(val) {
    _inPra = val;
    notifyListeners();
  }

  set setCou(val) {
    _inCou = val;
    notifyListeners();
  }
}
