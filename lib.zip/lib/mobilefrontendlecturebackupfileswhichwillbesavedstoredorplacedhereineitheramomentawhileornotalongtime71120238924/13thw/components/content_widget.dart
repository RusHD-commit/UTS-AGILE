import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/13thmeetingprovider.dart';

class ContentWidget extends StatelessWidget {
  const ContentWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M13MProvider>(context);
    return Center(
      child: Container(
        child: prov.stillGrilling == true
            ? SizedBox(
                width: 100,
                child: TweenAnimationBuilder(
                    duration: Duration(seconds: prov.sliderValue.round()),
                    tween: Tween<double>(begin: 0, end: 1),
                    builder: (context, double value, _) =>
                        LinearProgressIndicator(
                          value: value,
                        )),
              )
            : prov.hasFinishedCooking == true
                ? Tooltip(
                    message: 'Grilled Wagyu Beef',
                    child: Image.network(
                      'https://www.dartagnan.com/dw/image/v2/BJQL_PRD/on/demandware.static/-/Sites-dartagnan-Library/default/dw0615f0e8/images/content/grilled-wagyu-filet-mignon-recipe.jpg?sw=1440&strip=false',
                      width: 300,
                    ),
                  )
                : Container(),
      ),
    );
  }
}
