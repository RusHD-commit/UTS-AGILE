import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/13thmeetingprovider.dart';

class SlideWidget extends StatelessWidget {
  const SlideWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M13MProvider>(context);
    return Slider(
      value: prov.sliderValue,
      min: 0,
      max: 10,
      label: prov.sliderValue.round().toString(),
      onChanged: (value) {
        prov.setSliderValue = value;
      },
    );
  }
}
