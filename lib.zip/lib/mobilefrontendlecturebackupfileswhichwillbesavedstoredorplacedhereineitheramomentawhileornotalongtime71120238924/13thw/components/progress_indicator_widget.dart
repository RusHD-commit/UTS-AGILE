import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/13thmeetingprovider.dart';

class ProgressIndicatorWidget extends StatelessWidget {
  const ProgressIndicatorWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M13MProvider>(context);
    return ElevatedButton(
        style: ElevatedButton.styleFrom(minimumSize: Size(100, 90)),
        onPressed: () {
          prov.startGrilling(prov.sliderValue.round());
        },
        child: prov.stillGrilling == true
            ? const CircularProgressIndicator(
                color: Color.fromARGB(60, 163, 150, 150),
              )
            : const Text('Grilling'));
  }
}
