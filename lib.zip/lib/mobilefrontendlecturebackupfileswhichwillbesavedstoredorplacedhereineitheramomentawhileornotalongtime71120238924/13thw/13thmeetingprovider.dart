import 'package:flutter/material.dart';

class M13MProvider extends ChangeNotifier {
  double _sliderValue = 0;
  double get sliderValue => _sliderValue;
  set setSliderValue(val) {
    _sliderValue = val;
    notifyListeners();
  }

  bool _stillGrilling = false;
  bool get stillGrilling => _stillGrilling;
  set setStillGrilling(val) {
    _stillGrilling = val;
  }

  bool _hasFinishedCooking = false;
  bool get hasFinishedCooking => _hasFinishedCooking;
  set hasFinishedCooking(val) {
    _hasFinishedCooking = val;
  }

  startGrilling(int val) async {
    setStillGrilling = true;
    Future.delayed(Duration(seconds: val), () {
      setStillGrilling = false;
      hasFinishedCooking = true;
    });
  }
}
