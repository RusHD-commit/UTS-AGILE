import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/13thmeetingprovider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/components/content_widget.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/components/progress_indicator_widget.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/13thw/components/slider_widget.dart';

class M13M extends StatefulWidget {
  const M13M({Key? key}) : super(key: key);

  @override
  State<M13M> createState() => _M13MState();
}

class _M13MState extends State<M13M> {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M13MProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('M13M')),
      //body: Text('M13M'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Grilling Duration: ${prov.sliderValue.round().toString()}'),
            const SlideWidget(),
            const Align(
              child: ProgressIndicatorWidget(),
              alignment: Alignment.bottomRight,
            ),
            const SizedBox(height: 100),
            const ContentWidget()
          ],
        ),
      ),
    );
  }
}
