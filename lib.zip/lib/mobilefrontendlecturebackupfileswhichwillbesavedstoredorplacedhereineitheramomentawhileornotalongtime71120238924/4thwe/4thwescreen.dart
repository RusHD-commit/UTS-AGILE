import 'package:flutter/material.dart';

class M04EBookList extends StatefulWidget {
  const M04EBookList({super.key});

  @override
  State<M04EBookList> createState() => _M04EBookListState();
}

class _M04EBookListState extends State<M04EBookList> {
  int ttlKeranjang = 0;
  bool isSelected = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List Buku"),
        actions: [
          Icon(Icons.shopping_basket_sharp),
          Text(
            ttlKeranjang.toString(),
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(width: 10)
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //List buku 1
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Text("Buku 1"),
                  Text("Desc"),
                ],
              ),
              Row(
                children: [
                  //icon 1
                  IconButton(
                    onPressed: () {
                      setState(() {
                        ttlKeranjang--;
                        isSelected = true;
                      });
                    },
                    icon: Icon(Icons.remove_circle),
                  ),

                  //icon 2
                  IconButton(
                    onPressed: () {
                      setState(() {
                        ttlKeranjang++;
                        isSelected = false;
                      });
                    },
                    icon: isSelected
                        ? Icon(Icons.add_box)
                        : Icon(Icons.check_box),
                  )
                ],
              )
            ],
          )
        ],
      ),
    );
  }
}
