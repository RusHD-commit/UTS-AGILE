import 'package:flutter/material.dart';

class M03 extends StatefulWidget {
  const M03({super.key});

  @override
  State<M03> createState() => _M03State();
}

class _M03State extends State<M03> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          //the header logo
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.accessibility_sharp, size: 50),
              Text(
                "Instagram",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.pinkAccent,
                ),
              ),
            ],
          ),

          /////SizedBox(height: 30),

          //Username Bar (section)
          Row(
            children: [
              Container(
                width: 80,
                margin: EdgeInsets.only(right: 10),
                padding: EdgeInsets.all(5),
                child: Text("Username: "),
              ),
              Expanded(
                child: TextField(
                  //controller: ,
                  decoration: InputDecoration(hintText: "Your Username"),
                ),
              )
            ],
          ),

          //Password Bar (section)
          Row(
            //width: 200,
            //padding: EdgeInsets.all(5),
            children: [
              Container(
                width: 80,
                margin: EdgeInsets.only(right: 10),
                padding: EdgeInsets.all(5),
                child: Text("Password: "),
              ),
              //Text("Password: "),
              Expanded(
                child: TextField(
                  /////controller: ctrlUsername,
                  obscureText: true,
                  //controller: ,
                  decoration: InputDecoration(hintText: "Your Password"),
                ),
              )
            ],
          ),

          //forgot password button
          TextButton(
            onPressed: () {
              print('Hello World');
            },
            child: const Text(
              'Forgot Password??',
              style: TextStyle(fontSize: 20),
            ),
          ),

          ElevatedButton(
            onPressed: () {
              print('Hello World');
            },
            child: Container(
              width: 75,
              padding: EdgeInsets.all(5),
              child: const Text(
                "Sign In",
                style: TextStyle(color: Colors.indigoAccent),
              ),
              /////alignment:,
            ),
          ),
        ],
      ),
    );
  }
}
