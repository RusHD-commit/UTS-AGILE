import 'package:flutter/material.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/9thw/ninthmeetingtest.dart';

class M09M extends StatefulWidget {
  const M09M({super.key});

  @override
  State<M09M> createState() => _M09MState();
}

class _M09MState extends State<M09M> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("M09M"),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              Tab(
                child: Text("Music"),
              ),
              Tab(
                child: Text("Favorite"),
              ),
              Tab(
                child: Text("Saved"),
              ),
            ],
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                padding: EdgeInsets.all(16),
                decoration:
                    BoxDecoration(color: Color.fromARGB(255, 75, 60, 88)),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        child: Image.asset('assets/emmaw.png'),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "John Doe",
                              style: TextStyle(
                                  color: Color.fromARGB(57, 178, 161, 206),
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "John@mail.com",
                              style: TextStyle(
                                  color: Color.fromARGB(57, 178, 161, 206),
                                  fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                      ),
                    ]),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new M09Mtest()));
                },
                leading: Icon(Icons.inbox),
                title: Text('Inbox'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {},
                leading: Icon(Icons.save),
                title: Text('Archived'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {},
                leading: Icon(Icons.download),
                title: Text('Saved'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            buttonSheets(context),
            //TextButton(
            //onPressed: () {
            //print('Home');
            //},
            //child: Text('Home'),
            //),
            TextButton(
              onPressed: () {
                print('Favorite');
              },
              child: Text('Favorite'),
            ),
            TextButton(
              onPressed: () {
                print('Saved');
              },
              child: Text('Saved'),
            ),
          ],
        ),
      ),
    );
  }

  buttonSheets(BuildContext context) {
    return Builder(builder: ((context) {
      return Center(
          child: TextButton(
              onPressed: () {
                showBottomSheet(
                  enableDrag: true,
                  context: context,
                  builder: (context) {
                    final theme = Theme.of(context);
                    return Wrap(
                      children: [
                        ListTile(
                          title: const Text(
                            'Header',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Color.fromARGB(60, 115, 114, 116),
                            ),
                          ),
                          tileColor: theme.colorScheme.primary,
                          trailing: IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: Icon(Icons.close,
                                color: Color.fromARGB(60, 115, 114, 116)),
                          ),
                        ),
                        ListTile(
                          title: Text("Facebook"),
                        ),
                        ListTile(
                          title: Text("Twitter"),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text("Social Media Share")));
    }));
  }
}
