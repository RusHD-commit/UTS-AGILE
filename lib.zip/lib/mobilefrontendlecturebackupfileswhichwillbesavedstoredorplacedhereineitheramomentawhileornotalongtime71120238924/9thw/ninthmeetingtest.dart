import 'package:flutter/material.dart';

class M09Mtest extends StatelessWidget {
  const M09Mtest({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Test"),
      ),
    );
  }
}
