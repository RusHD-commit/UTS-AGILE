import 'package:flutter/material.dart';

class M07MSecondBody extends StatelessWidget {
  final String image;
  const M07MSecondBody({Key? key, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Image.asset(image, width: 70),
    );
  }
}
