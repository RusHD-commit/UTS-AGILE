import 'package:flutter/material.dart';

class M07MProvider extends ChangeNotifier {
  int _ttlNotif = 0;

  bool _selected = false;

  bool get selected => _selected;

  setSelected() {
    if (selected == false) {
      _selected = true;
    } else {
      selected == false;
    }
  }

  int get ttlNotif => _ttlNotif;
  set setTTLNotif(int val) {
    _ttlNotif += val;
    notifyListeners();
  }

  resetNotif() {
    _ttlNotif += 0;
    notifyListeners();
  }
}
