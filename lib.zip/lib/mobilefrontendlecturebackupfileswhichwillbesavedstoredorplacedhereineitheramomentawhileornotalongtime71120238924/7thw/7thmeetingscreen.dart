import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/7thw/7thmeeting_provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/7thw/7thmeetingbody.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/7thw/7thmeetingsecondbody.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/7thw/7thmeetingthirdbody.dart';

class M07M extends StatefulWidget {
  const M07M({super.key});

  @override
  State<M07M> createState() => _M07MState();
}

class _M07MState extends State<M07M> {
  int _currentIndex = 0;
  int selected = 0;
  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M07MProvider>(context);
    final List _body = [
      const M07MBody(title: "Home"),
      const M07MBody(title: "Chat"),
      const M07MBody(title: "Profile"),
    ];
    final List _secondbody = [
      const M07MSecondBody(image: 'assets/kqing1.png'),
      const M07MSecondBody(image: 'assets/mikukun1.png'),
      const M07MSecondBody(image: 'assets/toyota1.png'),
    ];

    final List _thirdbody = [
      const M07MThirdBody(tezxt: 'Test1'),
      const M07MThirdBody(tezxt: 'Test2'),
      const M07MThirdBody(tezxt: 'Test3'),
    ];
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          prov.setTTLNotif = 1;
          prov.setSelected();
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        //onTap: (val) {},
        onTap: onTabTapped,
        currentIndex: _currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mail),
            label: 'Mail',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Person',
          ),
        ],
      ),
      appBar: AppBar(
        leading: const Icon(Icons.menu),
        //title: const Text('M07M'),
        title: Container(
          child: _body[_currentIndex],
        ),
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.notifications),
              Positioned(
                top: 10,
                right: 0,
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Color.fromARGB(255, 241, 207, 93)),
                  child: Text(
                    prov.ttlNotif.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12,
                        color: Color.fromARGB(31, 41, 41, 41),
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: IconButton(
                onPressed: () {
                  prov.resetNotif();
                },
                icon: const Icon(Icons.delete)),
          ),
          const Icon(Icons.more_vert)
        ],
        backgroundColor: Colors.purple,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              child: _body[_currentIndex],
            ),
            Container(
              child: _secondbody[_currentIndex],
            ),
            Container(
              child: _thirdbody[_currentIndex],
            ),
            if (prov.selected) Text("test") else Text("test2"),
          ],
        ),
      ), //child: FloatingActionButton:FloatingAction,
    );
  }
}
