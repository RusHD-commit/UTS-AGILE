import 'package:flutter/material.dart';

class M07MBody extends StatelessWidget {
  final String title;
  const M07MBody({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          //Image.asset('assets/emmaw.png', width: 30),
        ],
      ),
    );
  }
}
