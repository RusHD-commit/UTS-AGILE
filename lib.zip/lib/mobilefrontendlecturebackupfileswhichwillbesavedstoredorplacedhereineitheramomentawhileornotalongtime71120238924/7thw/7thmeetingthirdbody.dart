import 'package:flutter/material.dart';

class M07MThirdBody extends StatelessWidget {
  final String tezxt;
  const M07MThirdBody({Key? key, required this.tezxt});

  @override
  Widget build(BuildContext context) {
    return Container(child: Text(tezxt));
  }
}
