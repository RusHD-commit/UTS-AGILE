import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/6thw/6thmeeting_provider.dart';

class M06M extends StatefulWidget {
  const M06M({super.key});

  @override
  State<M06M> createState() => _M06MState();
}

class _M06MState extends State<M06M> {
  String itemSelected = 'Student';
  List items = [
    'Student',
    'Lecturer',
    'C',
    'D',
    'E',
  ];
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<M06MProvider>(context);
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Dark mode Theme'),
                Switch(
                  value: prov.enableDarkMode,
                  activeColor: Color.fromARGB(250, 8, 59, 35),
                  onChanged: (val) {
                    //print(val);
                    prov.setBrightness = val;
                  },
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Dark mode Theme'),
                Switch(
                  value: false,
                  activeColor: Color.fromARGB(250, 8, 59, 35),
                  onChanged: (val) {
                    print(val);
                    //prov.setBrightness = val;
                  },
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Occupation'),
                DropdownButton(
                  items: items.map((item) {
                    return DropdownMenuItem(
                      child: Text(item),
                      value: item,
                    );
                  }).toList(),
                  value: itemSelected,
                  onChanged: (val) {
                    setState(() {
                      itemSelected = val as String;
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
