import 'package:flutter/material.dart';

class M06MProvider extends ChangeNotifier {
  var light = ThemeData(
    brightness: Brightness.light,
    //primarySwatch: Color.fromARGB(255, 93, 83, 102),
    primarySwatch: Colors.green,
  );
  var dark = ThemeData(
    brightness: Brightness.dark,
    primarySwatch: Colors.green,
  );

  bool _enableDarkMode = false;

  bool get enableDarkMode => _enableDarkMode;
  set setBrightness(val) {
    _enableDarkMode = val;
    notifyListeners();
  }
}
