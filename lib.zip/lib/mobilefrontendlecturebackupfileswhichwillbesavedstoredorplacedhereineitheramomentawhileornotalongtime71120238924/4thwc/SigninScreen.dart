import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/4thwc/Basket2screen.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/4thwc/SignInScreenProvider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/4thwc/components/widget_productofBasket2screen.dart';

class ProductScreen2 extends StatelessWidget {
  const ProductScreen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final vicky = context.read<ProductBasketProvider>();
    final albert = context.watch<ProductBasketProvider>();
    return Scaffold(
      appBar: AppBar(
          title: Text(context.read<ProductBasketProvider>().titleScreen),
          actions: [
            Stack(children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => Basket2())));
                },
              ),

              //keranjang belanja
              Positioned(
                  child: Text(
                albert.keranjang.length.toString(),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ))
            ]),
          ]),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          ProductWidget(
            namaProduk: 'Tas',
            ctrl: albert.tasCtrl,
            status: albert.isTasAdd,
            press: () {
              print('Tas');
              vicky.setTasStatus = true;
              vicky.isiKeranjang = {
                "title": 'Tas',
                "total": context.read<ProductBasketProvider>().tasCtrl.text
              };
            },
          ),

          //berhasil jika tas telah ditambah.
          context.watch<ProductBasketProvider>().isTasAdd == true
              ? Text('Berhasil')
              : Container(),

          context.watch<ProductBasketProvider>().isTasAdd == true
              ? ElevatedButton(
                  onPressed: () {
                    //Hapus Data array
                    context.read<ProductBasketProvider>().hapusIsiKerangan();

                    context.read<ProductBasketProvider>().setTasStatus = false;
                  },
                  child: Text('Hapus'))
              : Container(),

          OutlinedButton(
              onPressed: () {
                context.read<ProductBasketProvider>().terimaAmplop('50.000');
              },
              child: context.read<ProductBasketProvider>().kantongDoraemon == ""
                  ? Text('Isi Kantong Doraemon adalah: 0')
                  : Text(
                      context.watch<ProductBasketProvider>().kantongDoraemon))
        ]),
      ),
    );
  }
}
