import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/4thwc/SignInScreenProvider.dart';

class Basket2 extends StatelessWidget {
  const Basket2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = context.read<ProductBasketProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('List Keranjang'),
      ),
      body: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              const Text(
                'List Belanja',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              Divider(),
              //List Keranjang
              Column(
                children: provider.keranjang.map((val) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      //kiri
                      Text(
                        '${val['title']}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),

                      //kanan
                      Text('${val['total']} item')
                    ],
                  );
                }).toList(),
              ),

              const SizedBox(height: 20),
              //Button CheckOut
              Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                    onPressed: () {
                      //Bagaimana cara hapus list keranjang belanja?
                    },
                    style: ElevatedButton.styleFrom(minimumSize: Size(100, 40)),
                    child: const Text('CheckOut')),
              )
            ],
          )),
    );
  }
}
