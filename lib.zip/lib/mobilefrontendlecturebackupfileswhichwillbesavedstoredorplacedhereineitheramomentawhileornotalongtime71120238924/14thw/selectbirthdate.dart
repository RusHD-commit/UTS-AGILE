import 'package:flutter/material.dart';

class ChosenDate extends StatefulWidget {
  const ChosenDate({Key? key}) : super(key: key);

  @override
  State<ChosenDate> createState() => _ChosenDateState();
}

class _ChosenDateState extends State<ChosenDate> {
  String? _dte;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(children: [
        Text('Chosen Date: ${_dte.toString()}'),
        IconButton(
            onPressed: () async {
              var dte = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2021),
                  lastDate: DateTime(3100));

              if (dte != null) {
                setState(() {
                  // var withintlp = DateFormat.QQQ().format(dte);

                  //_dte = '${dte.day}-${dte.month}-${dte.year}';
                });
              } else {
                print('No dates chosen');
                setState(() {
                  _dte = '-';
                });
              }
            },
            icon: Icon(Icons.date_range_outlined))
      ]),
    );
  }
}
