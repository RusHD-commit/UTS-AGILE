import 'package:flutter/material.dart';
//import 'package:flutter_rus/14thw/selectbirthdate.dart';
import 'package:test1/mobilefrontendlecturebackupfileswhichwillbesavedstoredorplacedhereineitheramomentawhileornotalongtime71120238924/14thw/selectbirthdate.dart';

class M14M extends StatefulWidget {
  const M14M({Key? key}) : super(key: key);

  @override
  State<M14M> createState() => _M14MState();
}

class _M14MState extends State<M14M> {
  DateTime _date = DateTime.now();
  TextEditingController? _time;
  DateTime? initdate;
  DateTime? finaldate;

  var chosenDate;

  //XFile? image;

  TextEditingController? ctrlDate;

  @override
  void initState() {
    ctrlDate = TextEditingController(text: "00/00/0000");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('M14M'),
        ),
        //body: const Text('M14M'),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView(
            children: [
              ChosenDate(),
              TextButton(
                onPressed: () {
                  //   Navigator.of(context).push(
                  //showPicker(
                  //context: context,
                  //value: TimeOfDay(hour: 12, minute: 00),
                  //onChange: (time) {
                  //  print(time.format(context));
                  //  },
                  //  ),
                  //);
                },
                child: Text(
                  "Open Time Selector",
                  style: TextStyle(color: Color.fromARGB(206, 231, 221, 215)),
                ),
              ),
              Row(
                children: [
                  const Text('Date'),
                  const SizedBox(
                    width: 10.5,
                  ),
                  Expanded(
                      child: InputDatePickerFormField(
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2500),
                    onDateSubmitted: (date) {
                      setState(() {
                        _date = date;
                        print(_date);
                      });
                    },
                  )),
                  IconButton(
                      onPressed: () async {
                        var res = await showDatePicker(
                            context: context,
                            initialDate: _date,
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2500));

                        if (res != null) {
                          setState(() {
                            _date = res;
                          });
                        }
                      },
                      icon: const Icon(Icons.date_range_outlined))
                ],
              ),
              ListTile(
                title: const Text('Chosen Date'),
                subtitle: Text(_date.toString()),
              ),
              const Divider(),
              Row(
                children: [
                  const Text('Time: '),
                  const SizedBox(width: 10.5),
                  Expanded(
                    child: TextField(
                      enabled: false,
                      controller: _time,
                      decoration: const InputDecoration(labelText: 'Time'),
                    ),
                  ),
                  IconButton(
                      onPressed: () async {
                        var res = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.now(),
                        );
                      },
                      icon: const Icon(Icons.timer_outlined))
                ],
              )
            ],
          ),
        ));
  }
}
