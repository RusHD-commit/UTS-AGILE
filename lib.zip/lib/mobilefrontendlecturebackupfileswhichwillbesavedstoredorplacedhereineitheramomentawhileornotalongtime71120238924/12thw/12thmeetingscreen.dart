import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '12thmeetingprovider.dart';

class M12M extends StatefulWidget {
  const M12M({Key? key}) : super(key: key);

  @override
  State<M12M> createState() => _M12MState();
}

class _M12MState extends State<M12M> {
  @override
  void initState() {
    Future.microtask(() {
      Provider.of<M12MProvider>(context, listen: false).initialData();
    });
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('M12M'),
        actions: [
          menuList(context),
        ],
      ),
      body: Padding(padding: const EdgeInsets.all(16.0), child: body(context)),
    );
  }

  menuList(BuildContext context) {
    final prov = Provider.of<M12MProvider>(context);

    return PopupMenuButton(
      icon: const Icon(Icons.more_vert),
      itemBuilder: (context) {
        return <PopupMenuEntry>[
          PopupMenuItem(
            child: ListTile(
              onTap: () => prov.switchList('phone'),
              leading: const Icon(Icons.phone),
              title: const Text('phone'),
            ),
          ),
          const PopupMenuDivider(),
          PopupMenuItem(
            child: ListTile(
              onTap: () {
                print('laptop');
                prov.switchList('laptop');
                Navigator.pop(context);
              },
              leading: const Icon(Icons.laptop),
              title: const Text('Laptop'),
            ),
          ),
        ];
      },
    );
  }

  body(BuildContext context) {
    final prov = Provider.of<M12MProvider>(context);

    if (prov.data == null) {
      return const CircularProgressIndicator();
    } else {
      return ListView(
          shrinkWrap: true,
          children: List.generate(
            prov.data.length,
            (index) {
              var item = prov.data['data']![index];
              return GestureDetector(
                  onTap: () => print('To detail page (Ke halaman detail)'),
                  child: Column(
                    children: [
                      Card(
                        // elevation: 0,
                        clipBehavior: Clip.antiAlias,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Image.network(item['img']),
                              title: Text(item['model']),
                              subtitle: Text(
                                item['developer'],
                                style: TextStyle(
                                    color: Colors.black.withOpacity(0.6)),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Text(
                                item['desc'].toString().length >= 100
                                    ? item['desc']
                                            .toString()
                                            .substring(0, 100) +
                                        "...read more"
                                    : item['desc'],
                                style: TextStyle(
                                    color: Colors.black.withOpacity(0.6)),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                ButtonBar(
                                  alignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Rp. ${item['price'].toString()},-',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text('Rating ${item['rating'].toString()}'),
                                  ],
                                ),
                                Row(
                                  children: [
                                    IconButton(
                                        onPressed: () {
                                          print('has liked (telah disukai)');
                                        },
                                        icon: const Icon(Icons.thumb_up)),
                                    IconButton(
                                        onPressed: () {},
                                        icon: const Icon(Icons.share))
                                  ],
                                )
                              ],
                            ),
                          ],
                        ),
                      ),
                      Card(
                          child: Column(
                        children: [
                          //header
                          ListTile(
                            title: Text("data"),
                          ),

                          Container(
                            height: 200,
                            width: double.infinity,
                            child: ListView(
                              shrinkWrap: true,
                              physics: BouncingScrollPhysics(),
                              scrollDirection: Axis.horizontal,
                              children: [
                                Image.network(
                                    "https://t-2.tstatic.net/medan/foto/bank/images2/Contoh-gambar.jpg"),
                                SizedBox(width: 10),
                                Image.network(
                                    "https://creatphoto.files.wordpress.com/2012/07/street_by_hotfiresantud4jnp2a.jpg"),
                                SizedBox(width: 10),
                                Image.network(
                                    "https://paultan.org/image/2018/08/2018-W222-Mercedes-Benz-S450L-2-e1533295643157.jpg"),
                                SizedBox(width: 10),
                                Image.network(
                                    "https://zetadivision.com/wp-content/uploads/2023/06/ZETA_ANNOUNCE_IDV_230601-1024x576.jpg"),
                                SizedBox(width: 10),
                              ],
                            ),
                          ),

                          //konten

                          ListTile(
                            trailing: Icon(Icons.arrow_drop_down),
                          )
                        ],
                      )),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10)),
                          boxShadow: [
                            BoxShadow(
                              color: const Color.fromARGB(255, 235, 233, 233)
                                  .withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset:
                                  Offset(0, 3), // changes position of shadow
                            ),
                          ],
                        ),
                        child: Text("data"),
                      )
                    ],
                  ));
            },
          ));
    }
  }
}
