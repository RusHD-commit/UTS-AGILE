import 'package:flutter/material.dart';

class M04M extends StatefulWidget {
  const M04M({super.key});

  @override
  State<M04M> createState() => _M04MState();
}

class _M04MState extends State<M04M> {
  int total1 = 0;
  bool status = false;
  bool status2 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Book List",
          style: TextStyle(
            fontSize: 30,
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              //Icons.settings,
              Icons.shopping_basket_sharp,
              color: Colors.white,
            ),
            onPressed: () {
              // do something
            },
          ),
          Text(total1.toString()),
          SizedBox(
            width: 20,
          )
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            //color: Colors.amberAccent,
            //width: 100,
            //height: double.infinity,
            //margin: EdgeInsets.all(3.5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Text("1st Book (Book 1)"),
                    Text("Desc"),
                    //Container(child:)
                  ],
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        setState(() {
                          //total1++;
                          if (!status) {
                            total1++;
                            status = true;
                          } else {
                            total1--;
                            status = false;
                          }
                        });
                      },
                      //icon: Icon(Icons.add_box),
                      icon: status
                          ? Icon(Icons.check_box)
                          : Icon(Icons.add_box_rounded),
                    ),
                    IconButton(
                      onPressed: () {
                        setState(() {
                          total1--;
                        });
                      },
                      icon: Icon(Icons.remove_circle),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            //color: Colors.amberAccent,
            //width: 100,
            //margin: EdgeInsets.all(3.5),
            //height: double.infinity,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Text("2nd Book (Book 2)"),
                    Text("Desc"),
                    //Container(child:)
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      onPressed: () {
                        setState(() {
                          if (!status2) {
                            total1++;
                            status2 = true;
                          } else {
                            total1--;
                            status2 = false;
                          }
                        });
                      },
                      icon: status2
                          ? Icon(Icons.check_box)
                          : Icon(Icons.add_box_rounded),
                    ),
                    IconButton(
                      onPressed: () {
                        setState(() {
                          total1--;
                        });
                      },
                      icon: Icon(Icons.remove_circle),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
