import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class M02A extends StatefulWidget {
  const M02A({super.key});

  @override
  State<M02A> createState() => _M02AState();
}

class _M02AState extends State<M02A> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        //appBar: AppBar(),
        body: Column(
          children: [
            Container(
              alignment: Alignment.center,
              height: 115,
              width: double.infinity,
              margin: EdgeInsets.all(2.5),
              color: Colors.blueAccent,
              //child: Text("Header", style: TextStyle(fontSize: 20)),
              child: Row(
                children: [
                  Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(2),
                    child: Image.asset(
                      "assets/ladytruth89324.png",
                      alignment: Alignment.center,
                    ),
                  ),
                  Text(
                    "EmmaPedia",
                    style: TextStyle(
                      fontSize: 45,
                      color: Color.fromARGB(194, 198, 206, 213),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.center,
              height: 45,
              width: double.infinity,
              margin: EdgeInsets.all(2.5),
              padding: EdgeInsets.all(5),
              color: Colors.grey,
              child: (Text(
                  "This Website is created and configured by Emma Studios")),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              //mainAxisAlignment: MainAxisAlignment.spaceevenly,
              children: [
                Container(
                  color: Color.fromARGB(255, 146, 47, 47),
                  margin: EdgeInsets.all(2.5),
                  width: 190,
                  height: 575,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: 175,
                            child: Image.asset("assets/kqing1.png"),
                          ),
                          Container(
                            padding: EdgeInsets.all(0.9),
                            margin: EdgeInsets.all(1.5),
                            width: 175,
                            height: 370,
                            //color: Color.fromARGB(255, 119, 153, 155),
                            color: Color.fromARGB(255, 188, 168, 168),
                            alignment: Alignment.center,
                            child: Text(
                              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                              style: TextStyle(
                                  fontSize: 14.5,
                                  color: Color.fromARGB(255, 222, 216, 197)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  color: Color.fromARGB(255, 188, 168, 168),
                  margin: EdgeInsets.all(2.5),
                  width: 190,
                  height: 575,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        margin: EdgeInsets.all(1.5),
                        child: Text(
                          "Current Toyota Lineup",
                          style: TextStyle(
                            fontSize: 15,
                            color: Color.fromARGB(255, 112, 70, 84),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            color: Colors.white12,
                            child: Row(
                              children: [
                                Container(
                                  child: Image.asset(
                                    "assets/toyota1.png",
                                    alignment: Alignment.center,
                                    width: 90,
                                  ),
                                ),
                                Container(
                                  child: Text(
                                    "The Toyota Agya is a compact city car (A) which is manufactured and designed by Daihatsu and manufactured by Astra Daihatsu Motor since the end of 2013 (3rd quarter of 2013), Toyota Agya is also called the Toyota Wigo in some nations. The Toyota Agya was initially announced, launched and exhibited at the 20th Indonesia International Motor Show back in September 2012 as Daihatsu and Toyota's joint response to the Indonesian government's plan for the Low Cost Green Car (LCGC) program, This vehicle is primarily developed for most emerging markets especially the Philippines, Sri Lanka and Vietnam.",
                                    style: TextStyle(fontSize: 4),
                                  ),
                                  alignment: Alignment.centerRight,
                                  width: 95,
                                  height: 93,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            color: Colors.white12,
                            child: Row(
                              children: [
                                Container(
                                  child: Image.asset(
                                    "assets/toyota2.png",
                                    alignment: Alignment.topLeft,
                                    width: 90,
                                  ),
                                ),
                                Container(
                                  child: Text(
                                    "The A200 or the A250 series prototype is also known as the Toyota Raize. The Toyota Raize is a trendy and modern looking subcompact crossover SUV which is  manufactured by Daihatsu. It was unveiled and exhibited at the 46th Tokyo Motor Show on 23 October 2019 under the 'upcoming New Compact SUV name'. Toyota Raize is currently available, retailed and marketed in Japan and most international markets especially Indonesia. It is mostly identical with the Daihatsu Rocky and Subaru Rex (A Daihatsu Rocky based vehicle which is currently marketed in japan), differentiated by its front fascia (Appearance) which adopted Toyota's impressive corporate look.",
                                    style: TextStyle(fontSize: 4),
                                  ),
                                  alignment: Alignment.centerRight,
                                  width: 95,
                                  height: 93,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      //Row(children: [cont(img), cont(text)],),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            color: Colors.white12,
                            child: Row(
                              children: [
                                Container(
                                  child: Image.asset(
                                    "assets/toyota3.png",
                                    //alignment: Alignment.,
                                    width: 90,
                                  ),
                                ),
                                Container(
                                  child: Text(
                                    "The Toyota Fortuner, it is also known as the Toyota Hilux SW4 or the Toyota SW4 in most latin american countries, is a alluring, innovative and trendy ladder framed mid-size SUV manufactured by the Japanese automaker called Toyota since the end of 2004. The Fortuner is actually based on the Toyota IMV Platform which mainly developed for (is mainly for) ladder frame vehicles such as the Hilux and the Innova. It's currently marketed, retailed and available in most developing (emerging) countries including Thailand and India, additionaly it's (The Innovative Fortuner is) locally assembled and fabricated in many countries. ",
                                    style: TextStyle(fontSize: 4),
                                  ),
                                  alignment: Alignment.centerRight,
                                  width: 95,
                                  height: 93,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              alignment: Alignment.center,
              height: 45,
              width: double.infinity,
              margin: EdgeInsets.all(2.5),
              padding: EdgeInsets.all(5),
              color: Colors.grey,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    child: const Icon(
                      Icons.home_max_outlined,
                      color: Color.fromARGB(255, 18, 44, 57),
                      size: 35,
                    ),
                  ),
                  Container(
                    child: const Icon(
                      Icons.inbox_outlined,
                      color: Color.fromARGB(255, 18, 44, 57),
                      size: 35,
                    ),
                  ),
                  Container(
                    child: const Icon(
                      Icons.login_outlined,
                      color: Color.fromARGB(255, 18, 44, 57),
                      size: 35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
