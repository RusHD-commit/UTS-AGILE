import 'package:flutter/material.dart';

class M09A extends StatefulWidget {
  const M09A({super.key});

  @override
  State<M09A> createState() => _M09AState();
}

class _M09AState extends State<M09A> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("data"),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              Tab(
                child: Text('Music'),
              ),
              Tab(
                child: Text('Favorite'),
              ),
              Tab(
                child: Text('Saved'),
              ),
            ],
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                padding: EdgeInsets.all(16.0),
                decoration:
                    BoxDecoration(color: Color.fromARGB(196, 90, 62, 95)),
                child: (Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      child: Image.asset("assets/kqing1.png"),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'John Doe',
                            style: TextStyle(
                              color: Color.fromARGB(178, 236, 198, 198),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Data@Email.com',
                            style: TextStyle(
                              color: Color.fromARGB(178, 236, 198, 198),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                )),
              ),
              Divider(),
              ListTile(
                onTap: () {},
                leading: Icon(Icons.inbox),
                title: Text('Inbox'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {},
                leading: Icon(Icons.save),
                title: Text('Archived'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {},
                leading: Icon(Icons.download),
                title: Text('Saved'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            TextButton(
              onPressed: () {
                print('Home');
              },
              child: Text('Home'),
            ),
            TextButton(
              onPressed: () {
                print('Favorite');
              },
              child: Text('Favorite'),
            ),
            TextButton(
              onPressed: () {
                print('Saved');
              },
              child: Text('Saved'),
            ),
          ],
        ),
      ),
    );
  }
}
