import 'package:flutter/material.dart';

class M01 extends StatefulWidget {
  const M01({super.key});

  @override
  State<M01> createState() => _M01State();
}

class _M01State extends State<M01> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Rusdi Hardjo",
          style: TextStyle(fontSize: 30),
        ),
      ),
      body: Column(
        children: [
          //text
          Text(
            'text1',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 30,
              fontFamily: "arial",
              color: Colors.pinkAccent,
              letterSpacing: 2,
            ),
          ),
          //icon
          const Icon(
            Icons.check_circle_outline_rounded,
            color: Colors.blueGrey,
            size: 50,
          ),
          //image or pic
          Image.asset(
            "assets/ladytruth89324.png",
            width: 200,
          )
        ],
      ),
    );
  }
}
