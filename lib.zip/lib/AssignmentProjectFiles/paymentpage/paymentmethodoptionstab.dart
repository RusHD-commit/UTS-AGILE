import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:test1/AssignmentProjectFiles/homepage/homepage.dart';

class Payment extends StatefulWidget {
  const Payment({super.key});

  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              centerTitle: true,
              title: Padding(
                padding: EdgeInsets.symmetric(vertical: 35),
                child: Image.asset(
                  "images/kqing2.png",
                  width: 135,
                  alignment: Alignment.bottomCenter,
                ),
              ),
            ),
            preferredSize: Size.fromHeight(75)),
        body: Container(
          color: Color.fromARGB(235, 220, 233, 216),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(
              'We Only Accept Virtual Payments',
              style: GoogleFonts.mohave(textStyle: TextStyle(fontSize: 33.5)),
              textAlign: TextAlign.center,
            ),
            Divider(
              color: Color.fromARGB(214, 14, 40, 1),
              indent: 35,
              endIndent: 35,
            ),
            Padding(
              padding:
                  EdgeInsets.only(left: 7.5, top: 3.5, right: 7.5, bottom: 1.5),
              child: Container(
                padding: EdgeInsets.only(
                    left: 5.5, top: 3.5, right: 5.5, bottom: 7.5),
                color:
                    Color.fromARGB(204, 235, 235, 235), //(204, 235, 235, 235)
                alignment: Alignment.center,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7.5, vertical: 3.5),
                          child: Image.network(
                            'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo_ovo_purple.svg/2560px-Logo_ovo_purple.svg.png',
                            width: 215,
                            alignment: Alignment.center,
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => new HomeTab()));
                        }),
                    SizedBox(height: 15),
                    ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7.5, vertical: 3.5),
                          child: Image.network(
                            'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Gopay_logo.svg/2560px-Gopay_logo.svg.png',
                            width: 215,
                            alignment: Alignment.center,
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => new HomeTab()));
                        }),
                    SizedBox(height: 15),
                    ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7.5, vertical: 3.5),
                          child: Image.network(
                            'https://seeklogo.com//images/S/shopee-pay-logo-2217CDC100-seeklogo.com.png',
                            width: 215,
                            alignment: Alignment.center,
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => new HomeTab()));
                        }),
                    SizedBox(height: 15),
                    ElevatedButton(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7.5, vertical: 3.5),
                        child: Image.network(
                          'https://www.freepnglogos.com/uploads/visa-and-mastercard-logo-26.png',
                          width: 215,
                          alignment: Alignment.center,
                        ),
                      ),
                      onPressed: () => ScaffoldMessenger.of(context)
                        ..removeCurrentMaterialBanner()
                        ..showMaterialBanner(showBanner(context)),
                    ),
                  ],
                ),
              ),
            ),
          ]),
        ));
  }
}

showBanner(BuildContext context) {
  return MaterialBanner(
      content: const Text(
          'Bank Cards are unavailable now. It\u0027s currently under maintenance'),
      leading: const Icon(
        Icons.info,
        color: Color.fromARGB(214, 14, 40, 1),
      ),
      actions: [
        TextButton(
            onPressed: (() =>
                ScaffoldMessenger.of(context).hideCurrentMaterialBanner()),
            child: const Text('Dismiss')),
      ]);
}
