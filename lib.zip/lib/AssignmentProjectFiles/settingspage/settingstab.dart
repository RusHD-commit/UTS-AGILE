import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screen_wake/flutter_screen_wake.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:test1/AssignmentProjectFiles/homepage/homepage.dart';
import 'package:toggle_switch/toggle_switch.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  double brightness = 0.0;
  bool toggle = false;
  bool _switch = false;
  final usernameField = TextEditingController();
  final emailField = TextEditingController();
  final pwdfield = TextEditingController();
  final phonefield = TextEditingController();
  final idfield = TextEditingController();
  ThemeData _dark = ThemeData(
    brightness: Brightness.dark,
    primaryColor: Color.fromARGB(255, 75, 77, 73),
  );
  ThemeData _light = ThemeData(
    brightness: Brightness.light,
    primaryColor: Color.fromARGB(235, 139, 195, 74),
  );
  final double actualsbwidth = 145.5;

  DateTime _dateTime = DateTime.now();

  void _showDateAndTimePicker() {
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1939),
      lastDate: DateTime(2035),
    ).then((value) {
      setState(() {
        setState(() {
          _dateTime = value!;
        });
      });
    });
  }

  @override
  void initState() {
    super.initState();
    initPlatformBrightness();
  }

  Future<void> initPlatformBrightness() async {
    double bright;
    try {
      bright = await FlutterScreenWake.brightness;
    } on PlatformException {
      bright = 1.0;
    }
    if (!mounted) return;

    setState(() {
      brightness = bright;
    });
  }

  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: _switch ? _dark : _light,
      home: Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              centerTitle: true,
              title: Image.asset(
                "images/kqing2.png",
                width: 135,
                alignment: Alignment.bottomCenter,
              ),
            ),
            preferredSize: Size.fromHeight(75)),
        body: SingleChildScrollView(
          //length: 5,
          child: Container(
            color: Color.fromARGB(255, 220, 233, 216),
            child: Padding(
              padding:
                  EdgeInsets.only(left: 3.5, top: 7.5, right: 3.5, bottom: 5.5),
              child: Container(
                color: Color.fromARGB(199, 42, 108, 11),
                child: Column(
                  children: [
                    Text(
                      'Visual Settings',
                      style: GoogleFonts.mohave(
                          textStyle: TextStyle(fontSize: 37.5)),
                    ),
                    Container(
                      margin: const EdgeInsets.only(
                          left: 21.5, top: 17.5, right: 21.5, bottom: 19.5),
                      padding: const EdgeInsets.only(
                          left: 21.5, top: 17.5, right: 21.5, bottom: 19.5),
                      decoration: BoxDecoration(
                          color: Color.fromARGB(204, 235, 235, 235),
                          border:
                              Border.all(color: Color.fromARGB(255, 72, 64, 6)),
                          boxShadow: [
                            BoxShadow(
                                color: Color.fromARGB(255, 72, 64, 6),
                                spreadRadius: 3.5,
                                blurRadius: 3.5)
                          ]),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 3.5),
                              child: Text(
                                'Brightness',
                                style: GoogleFonts.mohave(
                                    textStyle: TextStyle(fontSize: 19.5)),
                              ),
                            ),
                            AnimatedCrossFade(
                                firstChild: const Icon(
                                    Icons.brightness_7_outlined,
                                    size: 53),
                                secondChild: const Icon(
                                    Icons.brightness_3_outlined,
                                    size: 53),
                                crossFadeState: toggle
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                duration: const Duration(seconds: 1)),
                            Expanded(
                                child: Slider(
                                    value: brightness,
                                    onChanged: (value) {
                                      setState(() {
                                        brightness = value;
                                      });
                                      FlutterScreenWake.setBrightness(
                                          brightness);
                                      if (brightness == 0) {
                                        toggle = true;
                                      } else {
                                        toggle = false;
                                      }
                                    })),
                          ],
                        )
                      ]),
                    ),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(
                        'Dark Mode: ',
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 19.5)),
                      ),
                      Switch(
                        value: _switch,
                        onChanged: (_newvalue) {
                          setState(() {
                            _switch = _newvalue;
                          });
                        },
                      ),
                    ]),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Text(
                      'Profile Settings',
                      style: GoogleFonts.mohave(
                          textStyle: TextStyle(fontSize: 37.5)),
                    ),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Your Username',
                          hintStyle: GoogleFonts.mohave(
                            textStyle: TextStyle(fontWeight: FontWeight.w500),
                            fontSize: 17,
                            //color: Colors.black26),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(210, 137, 136, 136)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(221, 233, 231, 231)),
                          ),
                          //borderRadius: BorderRadius.all(),
                          fillColor: Color.fromARGB(204, 235, 235, 235),
                          filled: true,
                        ),
                        controller: usernameField,
                        //hintText: 'Username',
                        obscureText: false,
                      ),
                    ),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Your Email Address',
                          hintStyle: GoogleFonts.mohave(
                            textStyle: TextStyle(fontWeight: FontWeight.w500),
                            fontSize: 17,
                            //color: Colors.black26),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(210, 137, 136, 136)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(221, 233, 231, 231)),
                          ),
                          //borderRadius: BorderRadius.all(),
                          fillColor: Color.fromARGB(204, 235, 235, 235),
                          filled: true,
                        ),
                        controller: emailField,
                        //hintText: 'Username',
                        obscureText: false,
                      ),
                    ),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Your Password',
                          hintStyle: GoogleFonts.mohave(
                            textStyle: TextStyle(fontWeight: FontWeight.w500),
                            fontSize: 17,
                            //color: Colors.black26),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(210, 137, 136, 136)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(221, 233, 231, 231)),
                          ),
                          //borderRadius: BorderRadius.all(),
                          fillColor: Color.fromARGB(204, 235, 235, 235),
                          filled: true,
                        ),
                        controller: pwdfield,
                        //hintText: 'Username',
                        obscureText: true,
                      ),
                    ),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Your Phone Number',
                          hintStyle: GoogleFonts.mohave(
                            textStyle: TextStyle(fontWeight: FontWeight.w500),
                            fontSize: 17,
                            //color: Colors.black26),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(210, 137, 136, 136)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(221, 233, 231, 231)),
                          ),
                          //borderRadius: BorderRadius.all(),
                          fillColor: Color.fromARGB(204, 235, 235, 235),
                          filled: true,
                        ),
                        controller: phonefield,
                        //hintText: 'Username',
                        obscureText: false,
                      ),
                    ),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Your ID Card Number',
                          hintStyle: GoogleFonts.mohave(
                            textStyle: TextStyle(fontWeight: FontWeight.w500),
                            fontSize: 17,
                            //color: Colors.black26),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(210, 137, 136, 136)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(221, 233, 231, 231)),
                          ),
                          //borderRadius: BorderRadius.all(),
                          fillColor: Color.fromARGB(204, 235, 235, 235),
                          filled: true,
                        ),
                        controller: idfield,
                        //hintText: 'Username',
                        obscureText: false,
                      ),
                    ),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ToggleSwitch(
                            customWidths: [95.5, 95.5],
                            cornerRadius: 17.5,
                            activeBgColors: [
                              [Colors.cyanAccent],
                              [Colors.redAccent]
                            ],
                            activeFgColor: Colors.white,
                            inactiveBgColor: Colors.grey,
                            inactiveFgColor: Colors.white,
                            totalSwitches: 2,
                            labels: ['Male', 'Female'],
                            icons: [Icons.male_outlined, Icons.female_outlined],
                            onToggle: (index) {
                              print('switched to: $index');
                            },
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                //padding: EdgeInsets.symmetric(horizontal: 35),
                                padding: EdgeInsets.symmetric(horizontal: 35),
                                child: SizedBox(
                                  width: actualsbwidth,
                                  child: OutlinedButton(
                                    onPressed: () {
                                      _showDateAndTimePicker();
                                    },
                                    style: ElevatedButton.styleFrom(
                                      //primary: Color.fromARGB(255, 244, 242, 242),
                                      primary: Color.fromARGB(224, 94, 146, 68),
                                      //onPrimary: Colors.black,
                                    ),
                                    child: Text(
                                        "Date of Birth", //Text("Already Have Account, Sign In",
                                        style: GoogleFonts.mohave(
                                          textStyle: TextStyle(
                                            //color: Colors.amberAccent,
                                            color: Color.fromARGB(
                                                204, 235, 235, 235),
                                            fontSize: 15,
                                          ),
                                        )),
                                  ),
                                ),
                              ),
                              Text(
                                _dateTime.toString(),
                                style: GoogleFonts.mohave(
                                  textStyle: TextStyle(
                                    //color: Colors.amberAccent,
                                    color: Color.fromARGB(204, 235, 235, 235),
                                    fontSize: 11.5,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ]),
                    Padding(
                      //padding: EdgeInsets.symmetric(horizontal: 35),
                      padding:
                          EdgeInsets.symmetric(horizontal: 35, vertical: 15),
                      child: SizedBox(
                        width: 355,
                        child: OutlinedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(showSnackBar(context));
                          },
                          style: ElevatedButton.styleFrom(
                            //primary: Color.fromARGB(255, 244, 242, 242),
                            primary: Color.fromARGB(224, 94, 146, 68),
                            //onPrimary: Colors.black,
                          ),
                          child: Text(
                              "Confirm Selection", //Text("Already Have Account, Sign In",
                              style: GoogleFonts.mohave(
                                textStyle: TextStyle(
                                  //color: Colors.amberAccent,
                                  color: Color.fromARGB(204, 235, 235, 235),
                                  fontSize: 15,
                                ),
                              )),
                        ),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    TextButton(
                        child: Text(
                          'Return to the Home Page',
                          style: GoogleFonts.mohave(
                              textStyle: TextStyle(fontSize: 33.5)),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => new HomeTab()));
                        }),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

showSnackBar(BuildContext context) {
  return SnackBar(
    behavior: SnackBarBehavior.floating,
    duration: Duration(seconds: 6),
    content: Text('Your Profile has successfuly been Configured'),
    action: SnackBarAction(
      label: 'Dismiss',
      onPressed: () => ScaffoldMessenger.of(context).removeCurrentSnackBar(),
    ),
  );
}
