import 'package:countries_flag/countries_flag.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Image.asset(
            "images/kqing2.png",
            width: 135,
            alignment: Alignment.bottomCenter,
          ),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              Tab(
                child: Text(
                  "About Us",
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
              ),
              Tab(
                child: Text(
                  "What is PolluCon",
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
              ),
              Tab(
                child: Text(
                  "Why Contribute",
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //Why Should We Contribute
              ),
              Tab(
                child: Text(
                  "User Stories",
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //User Stories of these stories I've created earlier
              ),
              Tab(
                child: Text(
                  "Group Profile",
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //Group Information & Profile
              ),
            ],
          ),
        ),
        body: //SingleChildScrollView(
            //child: Container(
            //color: Color.fromARGB(255, 220, 233, 216),
            //),
            //),

            TabBarView(
          children: [
            //buttonSheets(context),
            SingleChildScrollView(
              //about us
              child: Container(
                color: Color.fromARGB(255, 220, 233, 216),
                //child: TextButton(
                //onPressed: () {
                //print('About Us');
                //},
                //child: Text('About Us'),
                //),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Text(
                        "About Us",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Container(
                      color: Color.fromARGB(225, 6, 16, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                                left: 7.5,
                                top: 15.5,
                                right: 3.5,
                                bottom: 15.5), //(left: 15, top: 15, right: 5)
                            child: Image.network(
                              'https://aaqr.org/images/article_images/2020/feature/20-01-0004.jpg',
                              width: 115 * 2,
                              height: 55 * 2,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                right: 7.5, top: 15), //right: 15, top: 15
                            child: Container(
                              color: Color.fromARGB(221, 233, 231, 231),
                              width: 135, //335
                              height: 115, //75
                              alignment: Alignment.center,
                              child: Text(
                                'Nearly more than 69.0 Million were recycled each year which actually can cause pollution in entire world. Go Contribute & Donate to save the enviroment.',
                                style: GoogleFonts.vidaloka(
                                  textStyle: TextStyle(
                                    fontSize: 11.5, //13.5
                                  ),
                                ),
                                textAlign: TextAlign.justify,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      color: Color.fromARGB(214, 14, 40, 1),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                                left: 7.5,
                                top: 15.5,
                                right: 3.5,
                                bottom: 15.5), //left: 15, top: 15, right: 5
                            child: Container(
                              color: Color.fromARGB(221, 233, 231, 231),
                              width: 175, //375
                              height: 195, //95
                              alignment: Alignment.center,
                              child: Text(
                                'In Some Countries, Plastics are usually not in charge (complementary) when shopping some groceries in either a supermarket, grocer or convenience store. Thats why we should bring a recyclable plastic bag before shopping a lot of groceries in any stores',
                                style: GoogleFonts.vidaloka(
                                    textStyle: TextStyle(
                                  fontSize: 13.5, //13.5
                                )),
                                textAlign: TextAlign.justify,
                              ),
                            ),
                          ),
                          Column(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    top: 15, right: 7.5), //top: 15, right: 15
                                child: Image.network(
                                  'https://www.supermarketnews.com/sites/supermarketnews.com/files/styles/article_featured_retina/public/Woman-plastic-bag-single-use-plastic-waste.png?itok=LKMY9kwP',
                                  width: 115 * 1.5,
                                  height: 55 * 1.5,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    top: 15, right: 7.5), //top: 15, right: 15
                                child: Image.network(
                                  'https://ichef.bbci.co.uk/news/976/cpsprodpb/8E8E/production/_85349463_bags2getty.jpg',
                                  width: 115 * 1.5,
                                  height: 55 * 1.5,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(
                            'Never ever recycle plastic waste for any purpose',
                            style: GoogleFonts.mohave(
                                textStyle: TextStyle(fontSize: 37)), //57
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            '#SayGoodbyeToPlasticBags&Stuffs',
                            style: GoogleFonts.mohave(
                              textStyle: TextStyle(
                                fontSize: 25.5,
                                color: Color.fromARGB(255, 72, 64, 6),
                              ),
                            ), //57
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            SingleChildScrollView(
              //what is pollucon
              child: Container(
                color: Color.fromARGB(255, 220, 233, 216),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Text(
                        "What is Pollucon",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 3.5,
                        top: 3.5,
                        right: 3.5,
                        bottom: 15,
                      ),
                      child: Container(
                        height: 200,
                        width: double.infinity,
                        child: ListView(
                          shrinkWrap: true,
                          physics: BouncingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          children: [
                            Image.network(
                                "https://scx1.b-cdn.net/csz/news/800a/2014/singaporesfi.jpg"),
                            SizedBox(width: 10),
                            Image.network(
                                "https://i.guim.co.uk/img/static/sys-images/Guardian/Pix/pictures/2013/6/21/1371805910463/fb4817cd-bc95-4418-96e5-b1c65c8e16e7-460x276.jpeg?width=300&quality=45&auto=format&fit=max&dpr=2&s=4c07c92cf3a1e98ca9bb458847c1a29b"),
                            SizedBox(width: 10),
                            Image.network(
                                "https://imgs.mongabay.com/wp-content/uploads/sites/20/2019/07/31003532/Banner-e1564547966866.jpg"),
                            SizedBox(width: 10),
                            Image.network(
                                "https://blog.arcadia.com/assets/2017/08/pexels-photo-221012.jpeg"),
                            SizedBox(width: 10),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 15),
                      child: Container(
                        color: Color.fromARGB(221, 233, 231, 231),
                        //width: 75,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(
                                  left: 3.75, top: 15, right: 5, bottom: 15),
                              child: Image.network(
                                'https://aaqr.org/images/article_images/2020/feature/20-01-0004.jpg',
                                width: 115 * 2,
                                height: 55 * 2,
                              ),
                            ),
                            //Padding(
                            //padding: EdgeInsets.only(
                            //left: 3.75, top: 15, right: 5, bottom: 15),
                            //child: Image.network(
                            //'https://aaqr.org/images/article_images/2020/feature/20-01-0004.jpg',
                            //width: 115 * 2,
                            //height: 55 * 2,
                            //),
                            //),
                            //Padding(
                            //padding: EdgeInsets.only(
                            //left: 3.75, top: 15, right: 5, bottom: 15),
                            //child: Image.network(
                            //'https://aaqr.org/images/article_images/2020/feature/20-01-0004.jpg',
                            //width: 115 * 2,
                            //height: 55 * 2,
                            //),
                            //),
                            //Padding(
                            //padding: EdgeInsets.only(
                            //left: 3.75, top: 15, right: 5, bottom: 15),
                            //child: Image.network(
                            //'https://aaqr.org/images/article_images/2020/feature/20-01-0004.jpg',
                            //width: 115 * 2,
                            //height: 55 * 2,
                            //),
                            //),
                            Padding(
                              padding: EdgeInsets.only(
                                  right: 7.5, top: 15), //(right: 15, top: 15)
                              child: Container(
                                color: Color.fromARGB(221, 233, 231, 231),
                                width: 115, //335
                                height: 135, //75
                                alignment: Alignment.center,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: Text(
                                    'PolluCon is an online donation contribution application which helps everyone to save the earth from Pollution in many places including Urbanized cities, and forest & beaches.',
                                    style: GoogleFonts.vidaloka(fontSize: 13.5),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  right: 7.5, top: 15), //(right: 15, top: 15)
                              child: Container(
                                color: Color.fromARGB(221, 233, 231, 231),
                                width: 95, //335
                                height: 135, //75
                                alignment: Alignment.center,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: Text(
                                    'Contribution for this purpose is certainly more useful to help the environment and save the earth. Go Green and PolluCon always help everyone to contribute',
                                    style: GoogleFonts.vidaloka(fontSize: 13.5),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              top: 15, bottom: 15, left: 35, right: 15),
                          child: Text(
                            '5 Most Polluted Countries as of today',
                            style: GoogleFonts.mohave(
                                textStyle: TextStyle(fontSize: 21)),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CountriesFlag(
                              Flags.chad,
                              width: 15,
                              height: 55,
                              fit: BoxFit.cover,
                              alignment: Alignment.center,
                            ),
                            Text(
                              ' 1. Chad',
                              style: GoogleFonts.mohave(
                                  textStyle: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CountriesFlag(
                              Flags.iraq,
                              width: 15,
                              height: 55,
                              fit: BoxFit.cover,
                              alignment: Alignment.center,
                            ),
                            Text(
                              ' 2. Iran',
                              style: GoogleFonts.mohave(
                                  textStyle: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CountriesFlag(
                              Flags.pakistan,
                              width: 15,
                              height: 55,
                              fit: BoxFit.cover,
                              alignment: Alignment.center,
                            ),
                            Text(
                              ' 3. Pakistan',
                              style: GoogleFonts.mohave(
                                  textStyle: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CountriesFlag(
                              Flags.bahrain,
                              width: 15,
                              height: 55,
                              fit: BoxFit.cover,
                              alignment: Alignment.center,
                            ),
                            Text(
                              ' 4. Bahrain',
                              style: GoogleFonts.mohave(
                                  textStyle: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CountriesFlag(
                              Flags.bangladesh,
                              width: 15,
                              height: 55,
                              fit: BoxFit.cover,
                              alignment: Alignment.center,
                            ),
                            Text(
                              ' 5. Bangladesh',
                              style: GoogleFonts.mohave(
                                  textStyle: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            //TextButton(
            //onPressed: () {
            //print('What is PolluCon');
            //},
            //child: Text('What is PolluCon'),
            //),
            //TextButton(
            //onPressed: () {
            //print('Why Contribute');
            //},
            //child: Text('Why Contribute'),
            //),
            SingleChildScrollView(
              //why should we contribute
              child: Container(
                color: Color.fromARGB(255, 220, 233, 216),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Text(
                        "Why Contribute",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 3.5, top: 3.5, right: 3.5, bottom: 15),
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 3.5,
                          top: 3.5,
                          right: 3.5,
                          bottom: 15,
                        ),
                        child: Container(
                          height: 200,
                          width: double.infinity,
                          child: ListView(
                            shrinkWrap: true,
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            children: [
                              Image.network(
                                  "https://datadrivenlab.org/wp-content/uploads/2020/09/Nilsson_Kung-Faisal-Mosque.jpg"),
                              SizedBox(width: 10),
                              Image.network(
                                  "https://d3hnfqimznafg0.cloudfront.net/images/Article_Images/ImageForArticle_1200_16172002493019803.jpg"),
                              SizedBox(width: 10),
                              Image.network(
                                  "https://gazettengr.com/wp-content/uploads/Smog-1200x600.jpg"),
                              SizedBox(width: 10),
                              Image.network(
                                  "https://i.brecorder.com/wp-content/uploads/2019/03/pollution.jpg"),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 7.5, top: 3.5, right: 7.5, bottom: 15),
                      child: Text(
                        'Why should you help to contribute',
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 37)), //57
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 7.5,
                          top: 11.5,
                          bottom: 15,
                          right: 7.5), //right: 15, top: 15
                      child: Container(
                        color: Color.fromARGB(221, 233, 231, 231),
                        //width: 335, //335
                        //height: 75, //75
                        alignment: Alignment.center,
                        child: Text(
                          ' A hygienic environment has numerous advantages for our daily life. One of the methods for preserving the environment is beach cleanup.',
                          style: GoogleFonts.vidaloka(
                            textStyle: TextStyle(
                              fontSize: 17.5, //13.5
                            ),
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 5),
                      child: Container(
                        color: Color.fromARGB(214, 14, 40, 1),
                        height: 35,
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 3.5,
                          vertical: 7.5,
                        ),
                        child: Container(
                          color: Color.fromARGB(199, 42, 108, 11),
                          height: 175 * 3,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 7.5,
                                        top: 5,
                                        right: 3.5,
                                        bottom: 5),
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Container(
                                            width: 115,
                                            height: 95,
                                            child: Text(
                                              'Recycling has several causes such as:',
                                              style: GoogleFonts.mohave(
                                                  textStyle: TextStyle(
                                                fontSize: 13,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231),
                                              )), //57
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          Text(
                                            '- Existence of Litter in a Neighborhood.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Existence of Litter in a Neighborhood.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Construction initiatives.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Carelessness and laziness.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- The notion that littering has no repercussions.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Lack of trash containers.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Environmental education done incorrectly.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Low Penalties & fines.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Pack Dynamics.',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                        ])),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 7.5,
                                        top: 5,
                                        right: 3.5,
                                        bottom: 5),
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Container(
                                            width: 115,
                                            height: 95,
                                            child: Text(
                                              'What type of contribution donation we offer?',
                                              style: GoogleFonts.mohave(
                                                  textStyle: TextStyle(
                                                fontSize: 13,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231),
                                              )), //57
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          Text(
                                            '- Air Pollution',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Beach Cleaning',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Deforestation',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Donation for the Construction of Recycling Facility',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                          Text(
                                            '- Etc but anything related with pollution (anything harmful)',
                                            style: GoogleFonts.vidaloka(
                                              textStyle: TextStyle(
                                                fontSize: 9.5,
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231), //13.5
                                              ),
                                            ),
                                            textAlign: TextAlign.start,
                                          ),
                                        ]))
                              ]),
                        )),
                  ],
                ),
              ),
            ),
            //TextButton(
            //onPressed: () {
            //print('User Stories');
            //},
            //child: Text('User Stories'),
            //),

            SingleChildScrollView(
              //user stories
              child: Container(
                color: Color.fromARGB(255, 220, 233, 216),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Text(
                        "User Stories",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.5, vertical: 7.5),
                      child: Container(
                        color: Color.fromARGB(199, 42, 108, 11),
                        width: 335,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 7.5,
                                    top: 3.5,
                                    right: 7.5,
                                    bottom: 15),
                                child: Container(
                                    width: 315,
                                    height: 195,
                                    color: Color.fromARGB(221, 233, 231, 231),
                                    child: Row(children: [
                                      Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 3.5, vertical: 5.5),
                                        child: Container(
                                            width: 75,
                                            color:
                                                Color.fromARGB(226, 52, 57, 47),
                                            child: Image.network(
                                                'https://drive.google.com/uc?export=view&id=1D_NMp_hikG1SoaP-fczf0tSRC6r4HCYE')),
                                      ),
                                      Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 5, vertical: 3.5),
                                              child: Container(
                                                child: Text(
                                                  'Alexis Zhang',
                                                  style: GoogleFonts.vidaloka(
                                                    textStyle: TextStyle(
                                                      fontSize: 21.5, //13.5
                                                    ),
                                                  ),
                                                  textAlign: TextAlign.start,
                                                ),
                                              ),
                                            ),
                                            //Divider(
                                            //color: Color.fromARGB(214, 14, 40, 1),
                                            //indent: 35,
                                            //endIndent: 35,
                                            //),
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 7.5,
                                                  vertical: 3.5),
                                              child: Container(
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231),
                                                height: 75,
                                                width: 135,
                                                child: Text(
                                                  'As a Gardener, I want to keep my country clean and unpolluted',
                                                  style: GoogleFonts.vidaloka(
                                                    textStyle: TextStyle(
                                                      fontSize: 13.5, //13.5
                                                    ),
                                                  ),
                                                  textAlign: TextAlign.justify,
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 7.5,
                                                  vertical: 3.5),
                                              child: Container(
                                                color: Color.fromARGB(
                                                    221, 233, 231, 231),
                                                height: 55,
                                                width: 135,
                                                child: Text(
                                                  'Currently an educated Chinese American Gardener who graduated from The University of Melbourne with a bachelor major of agriculture',
                                                  style: GoogleFonts.vidaloka(
                                                    textStyle: TextStyle(
                                                      fontSize: 11.5, //13.5
                                                    ),
                                                  ),
                                                  textAlign: TextAlign.justify,
                                                ),
                                              ),
                                            ),
                                          ])
                                    ])),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 7.5,
                                    top: 3.5,
                                    right: 7.5,
                                    bottom: 15),
                                child: Container(
                                  width: 315,
                                  height: 195,
                                  color: Color.fromARGB(221, 233, 231, 231),
                                  child: Row(children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 3.5, vertical: 5.5),
                                      child: Container(
                                          width: 75,
                                          color:
                                              Color.fromARGB(226, 52, 57, 47),
                                          child: Image.network(
                                              'https://drive.google.com/uc?export=view&id=1qP0H_3V5R116cukMt1__uVCZicBl3KOs')),
                                    ),
                                    Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 7.5, vertical: 3.5),
                                            child: Container(
                                              child: Text(
                                                'Tom Jones',
                                                style: GoogleFonts.vidaloka(
                                                  textStyle: TextStyle(
                                                    fontSize: 21.5, //13.5
                                                  ),
                                                ),
                                                textAlign: TextAlign.start,
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 7.5, vertical: 3.5),
                                            child: Container(
                                              color: Color.fromARGB(
                                                  221, 233, 231, 231),
                                              height: 75,
                                              width: 135,
                                              child: Text(
                                                'As a Beach Cleaner, I wanted to find new ways to clean it',
                                                style: GoogleFonts.vidaloka(
                                                  textStyle: TextStyle(
                                                    fontSize: 13.5, //13.5
                                                  ),
                                                ),
                                                textAlign: TextAlign.justify,
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 7.5, vertical: 3.5),
                                            child: Container(
                                              color: Color.fromARGB(
                                                  221, 233, 231, 231),
                                              height: 55,
                                              width: 135,
                                              child: Text(
                                                'Currently an experienced beach cleaner from the UK for more than many years who have attended several beach cleaning programmes & graduated from Princeton University with a bachelor of Science',
                                                style: GoogleFonts.vidaloka(
                                                  textStyle: TextStyle(
                                                    fontSize: 11.5, //13.5
                                                  ),
                                                ),
                                                textAlign: TextAlign.justify,
                                              ),
                                            ),
                                          ),
                                        ])
                                  ]),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 7.5,
                                    top: 3.5,
                                    right: 7.5,
                                    bottom: 15),
                                child: Container(
                                    width: 315,
                                    height: 195,
                                    color: Color.fromARGB(221, 233, 231, 231),
                                    child: Row(children: [
                                      Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 3.5, vertical: 5.5),
                                        child: Container(
                                            width: 75,
                                            color:
                                                Color.fromARGB(226, 52, 57, 47),
                                            child: Image.network(
                                                'https://drive.google.com/uc?export=view&id=1ADt3aN1raK4HJK7qh12gn_-RVZHO6YoI')),
                                      ),
                                      Column(children: [
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 7.5, vertical: 3.5),
                                          child: Container(
                                            child: Text(
                                              'Carmelita Cruz',
                                              style: GoogleFonts.vidaloka(
                                                textStyle: TextStyle(
                                                  fontSize: 21.5, //13.5
                                                ),
                                              ),
                                              textAlign: TextAlign.start,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 7.5, vertical: 3.5),
                                          child: Container(
                                            color: Color.fromARGB(
                                                221, 233, 231, 231),
                                            height: 75,
                                            width: 135,
                                            child: Text(
                                              'As a Contributor I want to Help everyone to Advertise the app and donate some money for the app',
                                              style: GoogleFonts.vidaloka(
                                                textStyle: TextStyle(
                                                  fontSize: 13.5, //13.5
                                                ),
                                              ),
                                              textAlign: TextAlign.justify,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 7.5, vertical: 3.5),
                                          child: Container(
                                              color: Color.fromARGB(
                                                  221, 233, 231, 231),
                                              height: 55,
                                              width: 135,
                                              child: SingleChildScrollView(
                                                scrollDirection: Axis.vertical,
                                                child: Text(
                                                  'Currently A Filipino businesswoman & valued online contributor of this website & another contribution website who graduated at both prestigious universities which are NUS (National University of Singapore) & Harvard University. She had awarded A bachelor degree of business studies from NUS (National University of Singapore) & A masters degree of business studies from Harvard University. Aditionally, She is a valued membership of this contribution organization (PolluCon) & Other Contribution organization.',
                                                  style: GoogleFonts.vidaloka(
                                                    textStyle: TextStyle(
                                                      fontSize: 11.5, //13.5
                                                    ),
                                                  ),
                                                  textAlign: TextAlign.justify,
                                                ),
                                              )),
                                        ),
                                      ])
                                    ])),
                              ),
                            ]),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            //TextButton(
            //onPressed: () {
            //print('Group Profile');
            //},
            //child: Text('Group Profile'),
            //),
            SingleChildScrollView(
              //Group Information
              child: Container(
                color: Color.fromARGB(255, 220, 233, 216),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(15),
                      child: Text(
                        "Group Information",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Divider(
                      color: Color.fromARGB(214, 14, 40, 1),
                      indent: 35,
                      endIndent: 35,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 7.5, top: 15, right: 7.5, bottom: 13.5),
                      child: Container(
                        color: Color.fromARGB(199, 42, 108, 11),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 3.5,
                                    top: 5.5,
                                    right: 3.5,
                                    bottom: 7.5),
                                child: Text(
                                  'This mobile app is created by',
                                  style: GoogleFonts.mohave(
                                      textStyle:
                                          TextStyle(fontSize: 19.5)), //57
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Container(
                                color: Color.fromARGB(221, 233, 231, 231),
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15,
                                      top: 3.5,
                                      right: 15,
                                      bottom: 7.5),
                                  child: Image.network(
                                      'https://scontent.cdninstagram.com/v/t51.2885-19/37759667_448322952244890_4522876003235659776_n.jpg?stp=dst-jpg_s100x100&_nc_cat=100&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=kCjCpsm0TLwAX8581nd&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.cdninstagram.com&oh=00_AfB5DYQfACxnQjd0ugLLmfh1mWoKISYhn8iBDONzGcNv5w&oe=64D8C78A',
                                      width: 135),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 3.5,
                                    top: 5.5,
                                    right: 3.5,
                                    bottom: 7.5),
                                child: Text(
                                  'Rusdi Hardjo-211111322',
                                  style: GoogleFonts.mohave(
                                      textStyle:
                                          TextStyle(fontSize: 31.5)), //57
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 3.5,
                                    top: 5.5,
                                    right: 3.5,
                                    bottom: 7.5),
                                child: Text(
                                  'The Creator of this website',
                                  style: GoogleFonts.mohave(
                                      textStyle:
                                          TextStyle(fontSize: 19.5)), //57
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ]),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 3.5, top: 7.5, right: 3.5, bottom: 5),
                      child: Container(
                          color: Color.fromARGB(221, 233, 231, 231),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 3.5,
                                    top: 5.5,
                                    right: 3.5,
                                    bottom: 7.5),
                                child: Text(
                                  'Follow My IG',
                                  style: GoogleFonts.mohave(
                                      textStyle:
                                          TextStyle(fontSize: 39.5)), //57
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.all(5.5),
                                child: Image.network(
                                  'https://scontent.xx.fbcdn.net/v/t1.15752-9/361141479_1021264305541249_1099213151407470227_n.jpg?stp=dst-jpg_s403x403&_nc_cat=103&cb=99be929b-59f725be&ccb=1-7&_nc_sid=aee45a&_nc_ohc=NYeW-KqvFjwAX98oGe9&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AdRsUdir5Id84ZQDstXfj8-aNtrjME-XIkwHpjKoKRP0Vw&oe=64D8B8A6',
                                  width: 195,
                                ),
                              ),
                            ],
                          )),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
