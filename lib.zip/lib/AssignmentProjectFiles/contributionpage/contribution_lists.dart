import 'package:flutter/material.dart';

class Cont {
  late final int? id;
  final String? contId;
  final String? contName;
  final int? firstcontamount;
  final int? secondcontamount;
  final ValueNotifier<int>? quantity;
  final String? unitTag;
  final String? image;

  Cont(
      {required this.id,
      required this.contId,
      required this.contName,
      required this.firstcontamount,
      required this.secondcontamount,
      required this.quantity,
      required this.unitTag,
      required this.image});

  Cont.fromMap(Map<dynamic, dynamic> res)
      : id = res['id'],
        contId = res['contId'],
        contName = res['contName'],
        firstcontamount = res['firstcontamount'],
        secondcontamount = res['secondcontamount'],
        quantity = res['quantity'],
        unitTag = res['unitTag'],
        image = res['image'];

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'contId': contId,
      'contName': contName,
      'firstcontamount': firstcontamount,
      'secondcontamount': secondcontamount,
      'quantity': quantity,
      'unitTag': unitTag,
      'image': image,
    };
  }
}
