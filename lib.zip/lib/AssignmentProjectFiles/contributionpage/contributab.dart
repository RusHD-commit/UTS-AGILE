import 'package:badges/badges.dart' as badges;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:test1/AssignmentProjectFiles/contributionpage/contributab_provider.dart';
import 'package:test1/AssignmentProjectFiles/paymentpage/paymentmethodoptionstab.dart';

class Contributetab extends StatefulWidget {
  const Contributetab({super.key});

  @override
  State<Contributetab> createState() => _ContributetabState();
}

class Cont {
  //Book
  final String occurenceNames; //title
  final String occurenceImages;
  final String occurenceDescs;
  final String occurenceContsAmount;

  const Cont({
    required this.occurenceNames,
    required this.occurenceImages,
    required this.occurenceDescs,
    required this.occurenceContsAmount,
  });
}

const allOccurences = [
  //allBooks
  Cont(
      occurenceNames: 'Amazon Rainforest Deforestation',
      occurenceImages:
          'https://i.guim.co.uk/img/media/3c2697e548f2709937d847419071d45f9a5c7c1d/0_0_4455_2673/master/4455.jpg?width=1200&height=1200&quality=85&auto=format&fit=crop&s=1fc92a6eb4eeaad53d1a1bc8b2cf4202',
      occurenceDescs: 'Brazil',
      occurenceContsAmount:
          'Unchecked growth of ranching and irresponsible farming methods destroys forests and makes places more vulnerable to fires that can spread swiftly into the Amazon River.'), //Book //title
  Cont(
      occurenceNames: 'Air Pollution in Lahore, Pakistan',
      occurenceImages:
          'https://www.aljazeera.com/wp-content/uploads/2021/12/2021-11-24T084357Z_1443403538_RC2V0R9HG9Z4_RTRMADP_3_PAKISTAN-POLLUTION.jpg?resize=1920%2C1440',
      occurenceDescs: 'Pakistan',
      occurenceContsAmount:
          'In 2022, Pakistan had two of the five cities with the worst air quality. Pakistan ranked third nationally with a score of 70.9, followed by Bahrain with a score of 66.6.  Because air pollutants enter homes and other structures through doors, windows, and ventilation, indoor air pollution in Pakistan is just as deadly as outdoor pollution.'),
  Cont(
      occurenceNames: 'Cleaning Progress in Kamilo Beach, Hawaii',
      occurenceImages:
          'https://d1l18ops95qbzp.cloudfront.net/wp-content/2020/08/13154526/Kamilo-Beach-Ring-Debri.jpg',
      occurenceDescs: 'United States',
      occurenceContsAmount:
          'Due to the difficulty of accessing Kamilo Beach, plastic pollution grew unabated for many years.Bill Gilmartin, the group\\u0027s founder, saw the birth of a rare Hawaiian monk seal pup on the enormous mountains of plastic, which prompted him to organize the first cleanup here.'),
  Cont(
      occurenceNames: 'Pollution Plant Construction in Pennsylvania',
      occurenceImages:
          'https://www.abc27.com/wp-content/uploads/sites/55/2023/05/646e9cf6a7ea22.76549499.jpeg?w=2560&h=1440&crop=1',
      occurenceDescs: 'United States',
      occurenceContsAmount:
          'Environmental authorities claimed for many years that air pollution from a coal-fired power station in Pennsylvania on the Delaware River hurt inhabitants of New Jersey.'),
  Cont(
      occurenceNames: 'Beach Cleanup in Juhu Beach, Mumbai',
      occurenceImages:
          'https://images.hindustantimes.com/rf/image_size_960x540/HT/p2/2018/05/29/Pictures/standalone_4c24b46a-62a6-11e8-a998-12ee0acfa260.jpg',
      occurenceDescs: 'India',
      occurenceContsAmount:
          'Juhu Beach has transformed into a massive landfill, with the majority of the trash being made of plastic, including bags, bottles, and other items.'),
];

class _ContributetabState extends State<Contributetab> {
  final searchplocccontlist = TextEditingController(); //controller
  List<Cont> occurenceNamesLists = allOccurences; //books //allBooks
  // List<String> occurencedesc = [
  //'KG',
  //'Dozen',
  //'KG',
  //'Dozen',
  //'KG',
  //'KG',
  //'KG',
  //];
  //List<int> contAmount = [10, 20, 30, 40, 50, 60, 70];
  //List<Cont> occurenceImagesLists = allOccurences;
  int totalcart = 0;
  int totalamount = 0;
  bool isSelected = true;
  @override
  Widget build(BuildContext context) {
    //final prov = Provider.of<ContributeTabProvider>(context);
    return Scaffold(
      appBar: PreferredSize(
          child: AppBar(
              centerTitle: true,
              title: Padding(
                padding: EdgeInsets.symmetric(vertical: 35),
                child: Image.asset(
                  "images/kqing2.png",
                  width: 135,
                  alignment: Alignment.bottomCenter,
                ),
              ),
              actions: [
                Center(
                  child: badges.Badge(
                    badgeContent: Text(
                      totalcart.toString(), //'0'
                      style: TextStyle(
                        color: Color.fromARGB(60, 240, 239, 239),
                      ),
                    ),
                    //badgeAnimation: Duration(milliseconds: 300),
                    child: IconButton(
                        icon: Icon(Icons.shopping_basket_sharp),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => new Payment()));
                        }),
                  ),
                ),
                SizedBox(width: 35)
                //IconButton(
                //icon: Icon(
                ////Icons.settings,
                //Icons.shopping_basket_sharp,
                //color: Colors.white,
                //),
                //onPressed: () {
                //// do something
                //},
                //),
                ////Text(total1.toString()),
                //SizedBox(
                //width: 20,
                //)
              ]),
          preferredSize: Size.fromHeight(75)),
      body: Container(
        color: Color.fromARGB(255, 220, 233, 216),
        child: Padding(
          padding:
              EdgeInsets.only(left: 7.5, top: 11.5, right: 7.5, bottom: 9.5),
          child: Container(
            color: Color.fromARGB(199, 42, 108, 11),
            child: Column(children: [
              TextField(
                controller: searchplocccontlist,
                decoration: InputDecoration(
                  fillColor: Color.fromARGB(204, 235, 235, 235),
                  filled: true,
                  prefixIcon: const Icon(Icons.search_outlined),
                  hintText: 'Search Contributions Here',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(3.5),
                    borderSide: const BorderSide(
                      color: Color.fromARGB(214, 14, 40, 1),
                    ),
                  ),
                ),
                onChanged: searchOccurenceList,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: occurenceNamesLists.length, //books
                  itemBuilder: (context, index) {
                    final occurenceNamesList = occurenceNamesLists[index];
                    //final occurenceImagesList = occurenceImagesLists[index];
                    return Card(
                      child: Column(children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Image(
                                width: 175,
                                height: 175, //searchplcccontlists
                                image: NetworkImage(occurenceNamesList
                                    .occurenceImages
                                    .toString()),
                              ),
                              SizedBox(width: 7.5),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      occurenceNamesList.occurenceNames
                                          .toString(),
                                      style: GoogleFonts.mohave(
                                          textStyle: TextStyle(
                                              fontSize: 21.5,
                                              fontWeight: FontWeight.w700)),
                                    ),
                                    SizedBox(height: 7.5),
                                    Text(
                                        occurenceNamesList.occurenceDescs
                                            .toString() //occurencedesc[index].toString()
                                        ,
                                        style: GoogleFonts.mohave(
                                            textStyle: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600))),
                                    Text(
                                        "Desc: " +
                                            occurenceNamesList
                                                .occurenceContsAmount
                                                .toString(), //contAmount[index].toString()
                                        style: GoogleFonts.mohave(
                                            textStyle: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600))),
                                    Align(
                                        alignment: Alignment.centerRight,
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              ElevatedButton(
                                                //padding: EdgeInsets.only(right: 7.5),
                                                onPressed: () {
                                                  setState(() {
                                                    totalcart++;
                                                    isSelected = false;
                                                  });
                                                },
                                                child: Padding(
                                                  padding: EdgeInsets.only(
                                                      right: 3.5),
                                                  child: Container(
                                                    height: 95.5,
                                                    width: 155,
                                                    decoration: BoxDecoration(
                                                      color: Color.fromARGB(
                                                          214,
                                                          14,
                                                          40,
                                                          1), //color: Color.fromARGB(204, 235, 235, 235), (214,14,40,1)
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3.5),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        'Add this Contribution to the basket',
                                                        style:
                                                            GoogleFonts.mohave(
                                                          textStyle: TextStyle(
                                                              fontSize: 13.5,
                                                              color: Color
                                                                  .fromARGB(
                                                                      221,
                                                                      233,
                                                                      231,
                                                                      231)),
                                                        ),
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(height: 7.5),
                                              ElevatedButton(
                                                //padding: EdgeInsets.only(right: 7.5),
                                                onPressed: () {
                                                  setState(() {
                                                    totalcart--;
                                                    isSelected = true;
                                                  });
                                                },
                                                child: Padding(
                                                  padding: EdgeInsets.only(
                                                      right: 3.5),
                                                  child: Container(
                                                    height: 95.5,
                                                    width: 155,
                                                    decoration: BoxDecoration(
                                                      color: Color.fromARGB(
                                                          214,
                                                          14,
                                                          40,
                                                          1), //color: Color.fromARGB(204, 235, 235, 235), (214,14,40,1)
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3.5),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        'Rmv this Contribution from the basket',
                                                        style:
                                                            GoogleFonts.mohave(
                                                          textStyle: TextStyle(
                                                              fontSize: 13.5),
                                                        ),
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  //icon 1
                                                  IconButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        totalamount--;
                                                        isSelected = true;
                                                      });
                                                    },
                                                    icon: Icon(Icons
                                                        .remove_circle_outline),
                                                  ),

                                                  //icon 2
                                                  IconButton(
                                                      onPressed: () {
                                                        setState(() {
                                                          totalamount++;
                                                          isSelected = false;
                                                        });
                                                      },
                                                      icon: //isSelected
                                                          //? Icon(
                                                          //  Icons.add_box_outlined)
                                                          //: Icon(Icons.check_box),
                                                          Icon(Icons
                                                              .add_box_outlined)),
                                                  Text('Contribute 10,000',
                                                      style: GoogleFonts.mohave(
                                                          textStyle: TextStyle(
                                                              fontWeight: FontWeight
                                                                  .w300))) //(the amount of contribution must be a multiplication value of 10000 (the ones which can multiplied by 10))
                                                ],
                                              )
                                            ])),
                                  ],
                                ),
                              ),
                              //Text(index.toString()),
                            ]),
                      ]),
                    );
                  },
                ),
              ),
              Container(
                color: Color.fromARGB(204, 235, 235, 235),
                height: 53,
                child: Container(
                  child: Padding(
                    padding: EdgeInsets.only(
                        left: 5.5, top: 3.5, right: 7.5, bottom: 3.5),
                    child: Text(
                        'Total Amount Contributed: ' +
                            totalamount.toString() +
                            '0,000 IDR',
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 19.5))),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  void searchOccurenceList(String query) {
    final suggestions = allOccurences.where((occurenceNamesList) {
      final occtitle = occurenceNamesList.occurenceNames.toLowerCase();
      final input = query.toLowerCase();

      return occtitle.contains(input);
    }).toList();

    setState(() => occurenceNamesLists = suggestions);
  }
}
