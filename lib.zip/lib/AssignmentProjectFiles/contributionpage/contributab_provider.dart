import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ContributeTabProvider with ChangeNotifier {
  int _contAmount = 0; //counter
  int get contAmount => _contAmount;

  double _totalCont = 0.0; //totalprice
  double get totalCont => _totalCont;

  void _setPrefItems() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt('contitems_insidethecart', _contAmount);
    prefs.setDouble('total_cont', _totalCont);
    notifyListeners();
  }

  void _getPrefItems() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _contAmount = prefs.getInt('contitemsincart') ?? 0;
    _totalCont = prefs.getDouble('total_cont') ?? 0;
    notifyListeners();
  }

  void addTotalPrice(double contAmount) {
    _totalCont = _totalCont + contAmount;
    _setPrefItems();
    notifyListeners();
  }

  void drpTotalPrice(double contAmount) {
    _totalCont = _totalCont - contAmount;
    _setPrefItems();
    notifyListeners();
  }

  double getTotalPrice() {
    _getPrefItems();
    return _totalCont;
  }

  void addCounter() {
    _contAmount++;
    _setPrefItems();
    notifyListeners();
  }

  void drpCounter() {
    _contAmount--;
    _setPrefItems();
    notifyListeners();
  }

  int getCounter() {
    _getPrefItems();
    return _contAmount;
  }
}
