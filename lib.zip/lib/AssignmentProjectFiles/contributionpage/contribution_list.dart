import 'package:flutter/material.dart';

class Cont {
  late final int? id;
  final String? contId;
  final String? contName;
  final int? firstcontamount;
  final int? secondcontamount;
  final ValueNotifier<int>? quantity;
  final String? unitTag;
  final String? image;

  Cont(
      {required this.id,
      required this.contId,
      required this.contName,
      required this.firstcontamount,
      required this.secondcontamount,
      required this.quantity,
      required this.unitTag,
      required this.image});
}
