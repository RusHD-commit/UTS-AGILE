import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:test1/9thw/9thwtest.dart';
import 'package:test1/AssignmentProjectFiles/aboutpage/aboutpage.dart';
import 'package:test1/AssignmentProjectFiles/contributionpage/contributab.dart';
import 'package:test1/AssignmentProjectFiles/reviewpage/reviewtab.dart';
import 'package:test1/AssignmentProjectFiles/settingspage/settingstab.dart';
import 'package:test1/AssignmentProjectFiles/signinpage/signintab.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final double coverheight = 530;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              centerTitle: true,
              title: Padding(
                padding: EdgeInsets.symmetric(vertical: 35),
                child: Image.asset(
                  "images/kqing2.png",
                  width: 135,
                  alignment: Alignment.bottomCenter,
                ),
              ),
              //bottom: TabBar(
              //isScrollable: true,
              //tabs: [
              //Tab(
              //child: Text("Music"),
              //),
              //Tab(
              //child: Text("Favorite"),
              //),
              //Tab(
              //child: Text("Saved"),
              //),
              //],
              //),
            ),
            preferredSize: Size.fromHeight(75)),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                padding: EdgeInsets.all(16),
                decoration:
                    BoxDecoration(color: Color.fromARGB(199, 42, 108, 11)),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 25.5,
                        child: Container(
                          child: Image.asset('assets/kqing1.png'),
                          decoration: new BoxDecoration(
                              color: Color.fromARGB(214, 14, 40, 1),
                              borderRadius:
                                  new BorderRadius.all(Radius.circular(35))),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Hello Contributor",
                              style: GoogleFonts.mohave(
                                textStyle: TextStyle(
                                    color: Color.fromARGB(233, 230, 228, 233),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 31.5),
                              ),
                            ),
                            Text("Test@gmail.com",
                                style: GoogleFonts.mohave(
                                  textStyle: TextStyle(
                                      color: Color.fromARGB(233, 230, 228, 233),
                                      fontWeight: FontWeight.bold),
                                ))
                          ],
                        ),
                      ),
                    ]),
              ),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new HomeTab()));
                },
                leading: Icon(Icons.home_max_outlined),
                title: Text(
                  'Home',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new AboutPage()));
                },
                leading: Icon(Icons.info_outline_rounded),
                title: Text(
                  'About',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new Contributetab()));
                },
                leading: Icon(Icons.delete_outline_rounded),
                title: Text(
                  'Contribute Us',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new ReviewTab()));
                },
                leading: Icon(Icons.insert_comment_outlined),
                title: Text(
                  'Review',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new SettingsTab()));
                },
                leading: Icon(Icons.edit_note_outlined),
                title: Text(
                  'Settings & Edit Profile',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //Edit Profile
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              ListTile(
                onTap: () => ScaffoldMessenger.of(context)
                  ..removeCurrentMaterialBanner()
                  ..showMaterialBanner(showBanner(context)),
                leading: Icon(Icons.shopping_cart_outlined),
                title: Text(
                  'PolluShop',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //Edit Profile
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new SignIn()));
                },
                leading: Icon(Icons.switch_account_outlined),
                title: Text(
                  'Sign Out',
                  style: GoogleFonts.davidLibre(
                      textStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19.5,
                    //color: Color.fromARGB(255, 72, 64, 6),
                  )),
                ), //Edit Profile
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Container(
            color: Color.fromARGB(255, 220, 233, 216),
            child: Column(
              children: [
                Image.network(
                  'https://images.theconversation.com/files/284288/original/file-20190716-173347-6nglne.jpg?ixlib=rb-1.1.0&rect=8%2C16%2C5414%2C3615&q=45&auto=format&w=926&fit=clip',
                  //fit: BoxFit.cover,
                  //height: double.infinity,
                  width: double.infinity,
                  height: coverheight,
                  fit: BoxFit.cover,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(padding: const EdgeInsets.all(35)),
                    Padding(
                        padding: const EdgeInsets.only(bottom: 15),
                        child: Container(
                          color: Color.fromARGB(221, 233, 231, 231),
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 13.5),
                          child: Center(
                            child: Image.network(
                              "https://bdenvironment.com/wp-content/uploads/2019/03/Air-Pollution.jpg",
                              alignment: Alignment.topCenter,
                            ),
                          ),
                        )),
                    Padding(
                      padding:
                          EdgeInsets.only(left: 15, right: 15, bottom: 37.5),
                      child: Text(
                        "Welcome to PolluCon",
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 95,
                                color: Color.fromARGB(255, 72, 64, 6))),
                        //TextStyle(
                        //fontWeight: FontWeight.bold,
                        //fontSize: 170,
                        //),
                      ),
                    ),
                    Container(
                      color: Color.fromARGB(221, 233, 231, 231),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15),
                        child: Text(
                          'This Application actually helps everyone to save the Earth. Let the climate change & Go Green!',
                          style: GoogleFonts.mohave(
                              textStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 55,
                            //color: Color.fromARGB(255, 72, 64, 6),
                          )),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(5),
                      child: Image.network(
                        'https://www.politico.com/dims4/default/8a1a3b9/2147483647/legacy_thumbnail/1200x800%3E/quality/90/?url=https%3A%2F%2Fstatic.politico.com%2Fcapny%2Fsites%2Fdefault%2Ffiles%2Fa%20-%20air%20quality_0.png',
                        //fit: BoxFit.cover,
                        //height: double.infinity,
                        width: 750,
                        height: coverheight,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 15, top: 7.5, right: 15, bottom: 3.5),
                      child: Text(
                        "Our Social Media Platforms",
                        //style: TextStyle(fontSize: 17),
                        style: GoogleFonts.mohave(
                            textStyle: TextStyle(fontSize: 57)),
                      ),
                    ),
                    Padding(padding: EdgeInsets.all(15)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 15),
                          child: Container(
                            decoration: BoxDecoration(
                                color: Color.fromARGB(221, 233, 231, 231),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                border: Border.all(
                                    color: Color.fromARGB(226, 52, 57, 47),
                                    width: 3)),
                            width: 95,
                            height: 95,
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 5),
                              child: Image.network(
                                'https://www.iconpacks.net/icons/2/free-instagram-logo-icon-3497-thumb.png',
                                width: 75,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 15),
                          child: Container(
                            decoration: BoxDecoration(
                                color: Color.fromARGB(221, 233, 231, 231),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                border: Border.all(
                                    color: Color.fromARGB(226, 52, 57, 47),
                                    width: 3)),
                            width: 95,
                            height: 95,
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 5),
                              child: Image.network(
                                'https://www.pngkey.com/png/full/23-236793_youtube-free-download-on-mbtskoudsalg-png-youtube-logo.png',
                                width: 75,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 15),
                          child: Container(
                            decoration: BoxDecoration(
                                color: Color.fromARGB(221, 233, 231, 231),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                border: Border.all(
                                    color: Color.fromARGB(226, 52, 57, 47),
                                    width: 3)),
                            width: 95,
                            height: 95,
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 5),
                              child: Image.network(
                                'https://cdn-icons-png.flaticon.com/512/39/39552.png',
                                width: 75,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

showBanner(BuildContext context) {
  return MaterialBanner(
      content: const Text(
          'Sorry for the inconvenience, this tab is currently under maintenance'),
      leading: const Icon(
        Icons.info,
        color: Color.fromARGB(214, 14, 40, 1),
      ),
      actions: [
        TextButton(
            onPressed: (() =>
                ScaffoldMessenger.of(context).hideCurrentMaterialBanner()),
            child: const Text('Dismiss')),
      ]);
}
