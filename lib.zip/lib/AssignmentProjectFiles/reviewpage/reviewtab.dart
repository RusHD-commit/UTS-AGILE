import 'package:comment_box/comment/comment.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ReviewTab extends StatefulWidget {
  const ReviewTab({super.key});

  @override
  State<ReviewTab> createState() => _ReviewTabState();
}

class _ReviewTabState extends State<ReviewTab> {
  final formKey = GlobalKey<FormState>();
  final TextEditingController commentController = TextEditingController();
  List filedata = [
    {
      'name': 'PolluCon Management',
      'pic': 'https://picsum.photos/300/30',
      'message': 'Welcome To Pollucon Reviews',
      'date': '2021-01-01 12:00:00'
    },
  ];

  Widget commentChild(data) {
    return Container(
      //width: 335,
      child: ListView(
        shrinkWrap: true,
        //physics: NeverScrollableScrollPhysics(),
        children: [
          for (var i = 0; i < data.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(2.0, 8.0, 2.0, 0.0),
              child: ListTile(
                leading: GestureDetector(
                  onTap: () async {
                    // Display the image in large form.
                    print("Comment Clicked");
                  },
                  child: Container(
                    height: 50.0,
                    width: 50.0,
                    decoration: new BoxDecoration(
                        color: Color.fromARGB(214, 14, 40, 1),
                        borderRadius:
                            new BorderRadius.all(Radius.circular(35))),
                    child: CircleAvatar(
                        radius: 50,
                        backgroundImage: CommentBox.commentImageParser(
                            imageURLorPath: data[i]['pic'])),
                  ),
                ),
                title: Text(
                  data[i]['name'],
                  style: GoogleFonts.mohave(
                    textStyle: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                subtitle: Row(
                  children: [
                    Text(data[i]['message']),
                    IconButton(
                        padding: EdgeInsets.only(),
                        alignment: Alignment.centerRight,
                        onPressed: () {
                          print('has liked this review');
                        },
                        icon: const Icon(Icons.thumb_up)),
                    IconButton(
                        padding: EdgeInsets.only(),
                        alignment: Alignment.centerRight,
                        onPressed: () {
                          print('has disliked this review');
                        },
                        icon: const Icon(Icons.thumb_down)),
                  ],
                ),
                trailing: Column(
                  //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text(data[i]['date'], style: TextStyle(fontSize: 10)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        child: AppBar(
          centerTitle: true,
          title: Padding(
            padding: EdgeInsets.symmetric(vertical: 35),
            child: Image.asset(
              "images/kqing2.png",
              width: 135,
              alignment: Alignment.bottomCenter,
            ),
          ),
        ),
        preferredSize: Size.fromHeight(75),
      ),
      body: Padding(
          padding:
              EdgeInsets.only(left: 7.5, right: 7.5, top: 15, bottom: 11.5),
          child: body(context)),
    );
  }

  body(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: 55, vertical: 35), //(horizontal: 355, vertical: 75)
      color: Color.fromARGB(221, 233, 231, 231),
      child: Container(
        color: const Color.fromARGB(60, 240, 239, 239),
        child: CommentBox(
          userImage: CommentBox.commentImageParser(
              imageURLorPath: "assets/kqing1.png"),
          child: commentChild(filedata),
          labelText: 'Enter a comment...',
          errorText: 'Reviews cannot be blank',
          withBorder: false,
          sendButtonMethod: () {
            if (formKey.currentState!.validate()) {
              print(commentController.text);
              setState(() {
                var value = {
                  'name': 'Test@gmail.com',
                  'pic': 'assets/kqing1.png',
                  'message': commentController.text,
                  'date': '2021-01-01 12:00:00'
                };
                filedata.insert(0, value);
              });
              commentController.clear();
              FocusScope.of(context).unfocus();
            } else {
              print("Not validated");
            }
          },
          formKey: formKey,
          commentController: commentController,
          backgroundColor: Color.fromARGB(214, 14, 40, 1),
          textColor: Colors.white,
          sendWidget: Icon(Icons.send_outlined, size: 30, color: Colors.white),
        ),
      ),
    );
  }
}
