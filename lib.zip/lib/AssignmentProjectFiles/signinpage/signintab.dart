import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:test1/AssignmentProjectFiles/homepage/homepage.dart';
import 'package:test1/AssignmentProjectFiles/signinpage/regtab.dart';

class SignIn extends StatefulWidget {
  const SignIn({super.key});

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final usernameField = TextEditingController();
  final pwdfield = TextEditingController();
  final double actualsbwidth = 145.5;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment(0.9, 1.1),
            colors: <Color>[
              Color.fromARGB(227, 25, 214, 56),
              Color.fromARGB(199, 42, 108, 11),
              Color.fromARGB(214, 14, 40, 1),
            ],
          ),
        ),
        child: Column(
          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding:
                  //EdgeInsets.only(bottom: 35, top: 45, left: 35, right: 35), //default
                  EdgeInsets.only(bottom: 35, top: 45, left: 35, right: 35),
              child: //Image.asset(
                  //'plcon.png',
                  //width: 315,
                  //),
                  Image.network(
                'https://drive.google.com/uc?export=view&id=1AzecEZynRbAefgVYWvpzKI1okBDrnV14',
                width: 315,
              ),
            ),
            //Row(),
            Padding(
              //padding: EdgeInsets.symmetric(horizontal: 35),
              padding: EdgeInsets.symmetric(horizontal: 35, vertical: 15),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Your Email Address',
                  hintStyle: GoogleFonts.mohave(
                    textStyle: TextStyle(fontWeight: FontWeight.w500),
                    fontSize: 17,
                    //color: Colors.black26),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Color.fromARGB(210, 137, 136, 136)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Color.fromARGB(221, 233, 231, 231)),
                  ),
                  //borderRadius: BorderRadius.all(),
                  fillColor: Color.fromARGB(204, 235, 235, 235),
                  filled: true,
                ),
                controller: usernameField,
                //hintText: 'Username',
                obscureText: false,
              ),
            ),
            //Row(),
            Padding(
              //padding: EdgeInsets.symmetric(horizontal: 35),
              padding: EdgeInsets.symmetric(horizontal: 35, vertical: 15),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Your Account Password',
                  hintStyle: GoogleFonts.mohave(
                    textStyle: TextStyle(fontWeight: FontWeight.w500),
                    fontSize: 17,
                    //color: Colors.black26),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Color.fromARGB(210, 137, 136, 136)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Color.fromARGB(221, 233, 231, 231)),
                    //borderRadius: BorderRadius.all(),
                  ),
                  fillColor: Color.fromARGB(204, 235, 235, 235),
                  filled: true,
                ),
                controller: pwdfield,
                //hintText: 'Username',
                obscureText: true,
              ),
            ),
            Row(
              children: [
                Padding(
                  //padding: EdgeInsets.symmetric(horizontal: 35),
                  padding: EdgeInsets.only(left: 35, right: 15),
                  child: SizedBox(
                    width: actualsbwidth,
                    child: OutlinedButton(
                      onPressed: () {
                        //print(
                        //"Hello World, This Aplication is currently under maintenance");
                        Navigator.push(
                          context,
                          new MaterialPageRoute(
                            builder: (context) => new HomeTab(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        //primary: Color.fromARGB(255, 244, 242, 242),
                        primary: Color.fromARGB(224, 94, 146, 68),
                        //onPrimary: Colors.black,
                      ),
                      child: Text(
                          "Sign In", //Text("Already Have Account, Sign In",
                          style: GoogleFonts.mohave(
                            textStyle: TextStyle(
                              //color: Colors.amberAccent,
                              color: Color.fromARGB(204, 235, 235, 235),
                              fontSize: 15,
                            ),
                          )),
                    ),
                  ),
                ),
                Padding(
                  //padding: EdgeInsets.symmetric(horizontal: 35),
                  padding: EdgeInsets.only(left: 15, right: 35),
                  child: SizedBox(
                    width: actualsbwidth,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          new MaterialPageRoute(
                            builder: (context) => new RegTab(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        //primary: Color.fromARGB(255, 244, 242, 242),
                        primary: Color.fromARGB(224, 94, 146, 68),
                        //onPrimary: Colors.black,
                      ),
                      child: Text(
                        "Register",
                        style: GoogleFonts.mohave(
                          textStyle: TextStyle(
                            //color: Colors.amberAccent,
                            color: Color.fromARGB(204, 235, 235, 235),
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
