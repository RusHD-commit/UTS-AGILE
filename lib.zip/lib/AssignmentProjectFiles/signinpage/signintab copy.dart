import 'package:flutter/material.dart';

class SignIn2 extends StatefulWidget {
  const SignIn2({super.key});

  @override
  State<SignIn2> createState() => _SignIn2State();
}

class _SignIn2State extends State<SignIn2> {
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment(0.9, 1.1),
          colors: <Color>[
            Color.fromARGB(227, 25, 214, 56),
            Color.fromARGB(199, 42, 108, 11),
            Color.fromARGB(214, 14, 40, 1),
          ],
        ),
      ),
    );
  }
}
