import 'package:flutter/material.dart';
import 'package:test1/10thw/components/fullscreen_dialog_widget.dart';

class M10 extends StatefulWidget {
  const M10({super.key});

  @override
  State<M10> createState() => _M10State();
}

class _M10State extends State<M10> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 16,
          ),
          MaterialBanner(
              content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Banner',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    )
                  ]),
              actions: [
                TextButton(
                    onPressed: () => ScaffoldMessenger.of(context)
                      ..removeCurrentMaterialBanner()
                      ..showMaterialBanner(showBanner(context)),
                    child: const Text('Show Banner')),
              ]),
          MaterialBanner(
            content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Snackbars',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text('Snackbars provide brief messages about app processes.')
                ]),
            actions: [
              TextButton(
                child: const Text('Snackbar'),
                onPressed: () => ScaffoldMessenger.of(context)
                    .showSnackBar(showSnackBar(context)),
              )
            ],
          ),
          MaterialBanner(
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'Dialogs',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                )
              ],
            ),
            actions: [
              // TextButton(
              //     onPressed: () => ScaffoldMessenger.of(context)
              //       ..removeCurrentMaterialBanner()
              //       ..showMaterialBanner(showBanner(context)),
              //     child: const Text('Show Banner')),
              TextButton(
                  onPressed: () => showDialog(
                      context: context,
                      builder: (context) => showAlertDialog(context)),
                  child: const Text('Alert Dialog')),
              TextButton(
                  onPressed: () => showDialog(
                      context: context,
                      builder: (context) => showSimpleDialog(context)),
                  child: const Text('Simple Dialog')),
              TextButton(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          fullscreenDialog: true,
                          builder: ((context) => FullScreenDialog()))),
                  child: const Text('Fullscreen Dialog')),
            ],
          )
        ],
      ),
    );
  }
}

showBanner(BuildContext context) {
  return MaterialBanner(
      content: const Text('Welcome to the Banner information!'),
      leading: const Icon(
        Icons.info,
        color: Color.fromARGB(255, 131, 71, 22),
      ),
      actions: [
        TextButton(onPressed: (() {}), child: const Text('Agree')),
        TextButton(
            onPressed: (() =>
                ScaffoldMessenger.of(context).hideCurrentMaterialBanner()),
            child: const Text('Dismiss')),
      ]);
}

showAlertDialog(BuildContext context) {
  return AlertDialog(
    title: const Text('Reset settings'),
    content:
        const Text('This device will reset into the default factory settings'),
    actions: [
      TextButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text('CANCEL'),
      ),
      TextButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text('ACCEPT'),
      ),
    ],
  );
}

showSnackBar(BuildContext context) {
  return SnackBar(
    behavior: SnackBarBehavior.floating,
    duration: Duration(seconds: 6),
    content: Text('Welcome to snackbar'),
    action: SnackBarAction(
      label: 'Dismiss',
      onPressed: () => ScaffoldMessenger.of(context).removeCurrentSnackBar(),
    ),
  );
}

showSimpleDialog(BuildContext context) {
  return SimpleDialog(
    title: const Text('Set backup account'),
    children: List.generate(4, ((index) {
      return SimpleDialogOption(
        onPressed: () => Navigator.pop(context, 'mail$index@gmail.com'),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Icon(
              Icons.abc,
              size: 36.0,
              color: Color.fromARGB(255, 241, 198, 105),
            ),
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 16.0),
              child: Text('Username$index'),
            ),
          ],
        ),
      );
    })),
  );
}
