import 'package:flutter/material.dart';

class M09test extends StatelessWidget {
  const M09test({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Test"),
      ),
    );
  }
}
