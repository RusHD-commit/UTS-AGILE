import 'package:flutter/material.dart';

class M04MTryInit extends StatefulWidget {
  const M04MTryInit({super.key});

  @override
  State<M04MTryInit> createState() => _M04MTryInitState();
}

class _M04MTryInitState extends State<M04MTryInit> {
  bool? isDone;

  @override
  void initState() {
    isDone = false;
    getData();
    super.initState();
  }

  getData() async {
    await Future.delayed(Duration(seconds: 5), () {
      setState(() {
        isDone = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Selamat datang",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 80,
                color: isDone == false ? Colors.blue : Colors.red),
          ),
          isDone == true
              ? Text(
                  "Hello",
                  style: TextStyle(fontSize: 80, color: Colors.blue),
                )
              : CircularProgressIndicator(),
          ElevatedButton(
              onPressed: () async {
                setState(() {
                  isDone = false;
                });
                await getData();
              },
              child: Text("refresh"))
        ],
      )),
    );
  }
}
