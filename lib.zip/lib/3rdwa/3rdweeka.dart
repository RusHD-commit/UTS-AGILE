import 'package:flutter/material.dart';

class M03A extends StatefulWidget {
  const M03A({super.key});

  @override
  State<M03A> createState() => _M03AState();
}

class _M03AState extends State<M03A> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Todos",
          //textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 30,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(3.55),
            margin: EdgeInsets.fromLTRB(2.5, 35, 2.5, 2.5),
            //alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.list_alt),
                Container(
                    padding: EdgeInsets.all(3.55),
                    //margin: EdgeInsets.only(right: 11),
                    margin: EdgeInsets.fromLTRB(3.5, 3.5, 31, 3.5),
                    child: Text(
                      "Activity",
                      style: TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 19.7),
                    )),
                Expanded(
                  child: SizedBox(
                    width: 300,
                    child: TextField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(7.5)),
                          hintText: "Activity Title"),
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(11)),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(3.5),
            margin: EdgeInsets.fromLTRB(3.5, 3.5, 31, 3.5),
            child: Row(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.description_outlined),
                Container(
                  padding: EdgeInsets.all(3.55),
                  //margin: EdgeInsets.only(right: 11),
                  margin: EdgeInsets.fromLTRB(3.5, 3.5, 31, 3.5),
                  child: Text(
                    "Description",
                    style:
                        TextStyle(fontWeight: FontWeight.w700, fontSize: 19.7),
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(35, 3.5, 25.5, 3.5),
            padding: EdgeInsets.all(1.1),
            child: SizedBox(
              width: double.infinity,
              height: 100,
              child: SizedBox(
                height: 400,
                child: TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(7.5)),
                    hintText: "Add Descriptions",
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 55, horizontal: 20),
                  ),
                ),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                padding: EdgeInsets.all(3.5),
                margin: EdgeInsets.fromLTRB(3.5, 51, 3.5, 3.5),
                child: Column(
                  children: [
                    Container(
                      child: Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(3.5),
                            margin: EdgeInsets.all(3.5),
                            child: Icon(Icons.calendar_month),
                          ),
                          Text(
                            "Starting date",
                            style: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(3.5),
                      child: SizedBox(
                        width: 115.5,
                        child: TextField(
                          decoration: InputDecoration(hintText: "19-10-2022"),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(bottom: 7.5)),
                    Container(
                      margin: EdgeInsets.fromLTRB(3.5, 5.75, 3.5, 1.75),
                      child: SizedBox(
                        //width: 175.5, (chrome)
                        width: 171.5,
                        child: OutlinedButton(
                          onPressed: () {
                            print(
                                "Hello World, This Aplication is currently under maintenance");
                          },
                          style: ElevatedButton.styleFrom(
                            //primary: Color.fromARGB(255, 244, 242, 242),
                            primary: Color.fromARGB(255, 255, 255, 255),
                            //onPrimary: Colors.black,
                          ),
                          child: const Text(
                            "Cancel",
                            style: TextStyle(
                              //color: Colors.amberAccent,
                              color: Colors.cyan,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(3.5),
                margin: EdgeInsets.fromLTRB(3.5, 51, 3.5, 3.5),
                child: Column(
                  children: [
                    Container(
                      child: Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(3.5),
                            margin: EdgeInsets.all(3.5),
                            child: Icon(Icons.calendar_month_outlined),
                          ),
                          Text(
                            "Ending date",
                            style: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(3.5),
                      child: SizedBox(
                        width: 115.5,
                        child: Expanded(
                          child: TextField(
                            decoration: InputDecoration(hintText: "19-10-2022"),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(bottom: 7.5)),
                    Container(
                      margin: EdgeInsets.fromLTRB(3.5, 5.75, 3.5, 1.75),
                      padding: EdgeInsets.all(1.1),
                      child: SizedBox(
                        //width: 175.5, (chrome)
                        width: 171.5,
                        child: ElevatedButton(
                          onPressed: () {
                            print(
                                "Hello World, This Aplication is currently under maintenance");
                          },
                          child: const Text(
                            "Save",
                            //style: TextStyle(color: Colors.amberAccent),
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
